import React, { useState } from "react";
import { View, Text, ScrollView, Pressable, Dimensions, TextInput } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";

const { width: SCREEN_W } = Dimensions.get("window");
const TILE_SIZE = (SCREEN_W - 32 - 8) / 3;

const STORY_USERS = [
  { id: "1", name: "You", gradient: [Colors.primary, Colors.accent] as [string, string], hasStory: false, isYou: true },
  { id: "2", name: "Alex", gradient: [Colors.secondary, Colors.rose] as [string, string], hasStory: true },
  { id: "3", name: "Jordan", gradient: [Colors.violet, "#6BD4FF"] as [string, string], hasStory: true },
  { id: "4", name: "Sam", gradient: [Colors.accent, Colors.gold] as [string, string], hasStory: true },
  { id: "5", name: "Riley", gradient: [Colors.rose, Colors.violet] as [string, string], hasStory: true },
  { id: "6", name: "Casey", gradient: ["#6BD4FF", Colors.mint] as [string, string], hasStory: true },
];

const FEED_POSTS = [
  { id: "1", emoji: "🌆", likes: 284, type: "wide" },
  { id: "2", emoji: "🎨", likes: 91, type: "tall" },
  { id: "3", emoji: "🌸", likes: 143, type: "sq" },
  { id: "4", emoji: "🎵", likes: 512, type: "sq" },
  { id: "5", emoji: "🏄", likes: 327, type: "sq" },
  { id: "6", emoji: "🌈", likes: 889, type: "sq" },
  { id: "7", emoji: "🍣", likes: 204, type: "wide" },
  { id: "8", emoji: "🐾", likes: 67, type: "sq" },
  { id: "9", emoji: "🌙", likes: 445, type: "sq" },
];

const TRENDING_TAGS = ["#LovrhubLoves", "#QueerJoy", "#DateNight", "#FindYourPeople", "#Pride2025"];

const POST_GRADIENTS: [string, string][] = [
  [Colors.secondary, Colors.rose],
  [Colors.violet, "#6BD4FF"],
  [Colors.primary, Colors.accent],
  [Colors.accent, Colors.gold],
  [Colors.rose, Colors.violet],
  ["#6BD4FF", Colors.mint],
  [Colors.gold, Colors.accent],
  [Colors.mint, "#6BD4FF"],
  [Colors.violet, Colors.rose],
];

export default function ExploreScreen() {
  const [search, setSearch] = useState("");
  const [activeTag, setActiveTag] = useState("#LovrhubLoves");

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Search bar */}
        <View style={{ padding: 16, paddingBottom: 8 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: Colors.card,
              borderRadius: 16,
              paddingHorizontal: 14,
              paddingVertical: 10,
              borderWidth: 1,
              borderColor: Colors.border,
              gap: 8,
            }}
          >
            <Text style={{ fontSize: 16, opacity: 0.5 }}>🔍</Text>
            <TextInput
              value={search}
              onChangeText={setSearch}
              placeholder="Search people, posts, communities…"
              placeholderTextColor={Colors.textMuted}
              style={{ flex: 1, fontSize: 14, color: Colors.text }}
            />
          </View>
        </View>

        {/* Stories row */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 12, paddingBottom: 8 }}
        >
          {STORY_USERS.map((user) => (
            <Pressable
              key={user.id}
              style={({ pressed }) => ({
                alignItems: "center",
                gap: 5,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              {user.hasStory ? (
                <LinearGradient
                  colors={user.gradient}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{ width: 66, height: 66, borderRadius: 33, padding: 2.5 }}
                >
                  <View
                    style={{
                      flex: 1,
                      borderRadius: 31,
                      backgroundColor: Colors.surface,
                      alignItems: "center",
                      justifyContent: "center",
                      borderWidth: 2,
                      borderColor: Colors.surface,
                    }}
                  >
                    <Text style={{ fontSize: 28 }}>
                      {user.isYou ? "➕" : ["😊", "😎", "🥰", "😍", "🌈", "✨"][parseInt(user.id) % 6]}
                    </Text>
                  </View>
                </LinearGradient>
              ) : (
                <View
                  style={{
                    width: 66,
                    height: 66,
                    borderRadius: 33,
                    backgroundColor: Colors.card,
                    alignItems: "center",
                    justifyContent: "center",
                    borderWidth: 2,
                    borderColor: Colors.border,
                    borderStyle: "dashed",
                  }}
                >
                  <Text style={{ fontSize: 28 }}>➕</Text>
                </View>
              )}
              <Text style={{ fontSize: 11, color: Colors.textSecondary, fontWeight: "600" }}>
                {user.isYou ? "Your story" : user.name}
              </Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Trending tags */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8, paddingVertical: 8 }}
        >
          {TRENDING_TAGS.map((tag) => {
            const isActive = activeTag === tag;
            return (
              <Pressable key={tag} onPress={() => setActiveTag(tag)}>
                {isActive ? (
                  <LinearGradient
                    colors={[Colors.primary, Colors.rose]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20 }}
                  >
                    <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>{tag}</Text>
                  </LinearGradient>
                ) : (
                  <View
                    style={{
                      paddingHorizontal: 14,
                      paddingVertical: 7,
                      borderRadius: 20,
                      borderWidth: 1,
                      borderColor: Colors.border,
                      backgroundColor: Colors.card,
                    }}
                  >
                    <Text style={{ color: Colors.textSecondary, fontSize: 12, fontWeight: "600" }}>{tag}</Text>
                  </View>
                )}
              </Pressable>
            );
          })}
        </ScrollView>

        {/* Photo grid */}
        <View style={{ padding: 16, paddingTop: 8 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: Colors.text, marginBottom: 12 }}>
            🔥 Trending near you
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 4 }}>
            {FEED_POSTS.map((post, i) => {
              const isWide = post.type === "wide";
              const isTall = post.type === "tall";
              return (
                <Pressable
                  key={post.id}
                  style={({ pressed }) => ({
                    width: isWide ? TILE_SIZE * 2 + 4 : TILE_SIZE,
                    height: isTall ? TILE_SIZE * 2 + 4 : TILE_SIZE,
                    borderRadius: 14,
                    overflow: "hidden",
                    opacity: pressed ? 0.85 : 1,
                    transform: [{ scale: pressed ? 0.97 : 1 }],
                  })}
                >
                  <LinearGradient
                    colors={POST_GRADIENTS[i % POST_GRADIENTS.length]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
                  >
                    <Text style={{ fontSize: isTall ? 40 : isWide ? 36 : 28 }}>{post.emoji}</Text>
                    <View
                      style={{
                        position: "absolute",
                        bottom: 6,
                        right: 8,
                        flexDirection: "row",
                        alignItems: "center",
                        gap: 2,
                      }}
                    >
                      <Text style={{ fontSize: 10, color: "rgba(255,255,255,0.9)" }}>♥</Text>
                      <Text style={{ fontSize: 10, color: "rgba(255,255,255,0.9)", fontWeight: "700" }}>
                        {post.likes}
                      </Text>
                    </View>
                  </LinearGradient>
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </View>
  );
}
