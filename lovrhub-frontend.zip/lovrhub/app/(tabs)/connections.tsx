import React, { useState } from "react";
import { View, Text, ScrollView, Pressable, TextInput } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";

const MATCHES = [
  { id: "1", name: "Alex", gradient: [Colors.secondary, Colors.rose] as [string, string], unread: true },
  { id: "2", name: "Jordan", gradient: [Colors.violet, "#6BD4FF"] as [string, string], unread: false },
  { id: "3", name: "Sam", gradient: [Colors.accent, Colors.gold] as [string, string], unread: true },
  { id: "4", name: "Riley", gradient: [Colors.rose, Colors.violet] as [string, string], unread: false },
  { id: "5", name: "Casey", gradient: ["#6BD4FF", Colors.mint] as [string, string], unread: true },
];

const CONVERSATIONS = [
  {
    id: "1",
    name: "Alex",
    lastMsg: "Hey! Are you free this weekend? 😊",
    time: "2m",
    unread: 3,
    gradient: [Colors.secondary, Colors.rose] as [string, string],
    online: true,
  },
  {
    id: "2",
    name: "Jordan",
    lastMsg: "That photo you posted was stunning 🔥",
    time: "14m",
    unread: 0,
    gradient: [Colors.violet, "#6BD4FF"] as [string, string],
    online: true,
  },
  {
    id: "3",
    name: "Sam",
    lastMsg: "Lmao yes exactly!! 😂",
    time: "1h",
    unread: 1,
    gradient: [Colors.primary, Colors.accent] as [string, string],
    online: false,
  },
  {
    id: "4",
    name: "Riley",
    lastMsg: "Sent you a voice note 🎤",
    time: "3h",
    unread: 0,
    gradient: [Colors.rose, Colors.violet] as [string, string],
    online: false,
  },
  {
    id: "5",
    name: "Casey",
    lastMsg: "ok so i found this amazing spot 🌅",
    time: "Yesterday",
    unread: 2,
    gradient: ["#6BD4FF", Colors.mint] as [string, string],
    online: true,
  },
  {
    id: "6",
    name: "Morgan",
    lastMsg: "You: Thanks for the rec! ✨",
    time: "Mon",
    unread: 0,
    gradient: [Colors.gold, Colors.accent] as [string, string],
    online: false,
  },
];

export default function ConnectionsScreen() {
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"messages" | "matches">("messages");

  const filtered = CONVERSATIONS.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      {/* Tab switcher */}
      <View
        style={{
          flexDirection: "row",
          paddingHorizontal: 16,
          paddingTop: 12,
          paddingBottom: 8,
          gap: 10,
        }}
      >
        {(["messages", "matches"] as const).map((tab) => {
          const isActive = activeTab === tab;
          const label = tab === "messages" ? "Messages" : "Matches 🔥";
          return (
            <Pressable key={tab} onPress={() => setActiveTab(tab)} style={{ flex: 1 }}>
              {isActive ? (
                <LinearGradient
                  colors={[Colors.primary, Colors.accent]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={{ paddingVertical: 10, borderRadius: 16, alignItems: "center" }}
                >
                  <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>{label}</Text>
                </LinearGradient>
              ) : (
                <View
                  style={{
                    paddingVertical: 10,
                    borderRadius: 16,
                    alignItems: "center",
                    backgroundColor: Colors.card,
                    borderWidth: 1,
                    borderColor: Colors.border,
                  }}
                >
                  <Text style={{ color: Colors.textMuted, fontWeight: "600", fontSize: 14 }}>{label}</Text>
                </View>
              )}
            </Pressable>
          );
        })}
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {activeTab === "matches" ? (
          <View style={{ padding: 16 }}>
            <Text style={{ fontSize: 13, color: Colors.textMuted, fontWeight: "600", marginBottom: 14 }}>
              NEW MATCHES — SAY HI 👋
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 12 }}>
              {MATCHES.map((m) => (
                <Pressable
                  key={m.id}
                  style={({ pressed }) => ({
                    alignItems: "center",
                    gap: 6,
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <LinearGradient
                    colors={m.gradient}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={{ width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center" }}
                  >
                    <Text style={{ fontSize: 32 }}>
                      {["😊", "😎", "🥰", "😍", "🌈"][parseInt(m.id) % 5]}
                    </Text>
                  </LinearGradient>
                  {m.unread && (
                    <View
                      style={{
                        position: "absolute",
                        top: 0,
                        right: 0,
                        width: 18,
                        height: 18,
                        borderRadius: 9,
                        backgroundColor: Colors.primary,
                        borderWidth: 2,
                        borderColor: Colors.surface,
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Text style={{ color: "#fff", fontSize: 9, fontWeight: "800" }}>!</Text>
                    </View>
                  )}
                  <Text style={{ fontSize: 12, color: Colors.text, fontWeight: "700" }}>{m.name}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : (
          <View>
            {/* Search */}
            <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  backgroundColor: Colors.card,
                  borderRadius: 14,
                  paddingHorizontal: 12,
                  paddingVertical: 9,
                  borderWidth: 1,
                  borderColor: Colors.border,
                  gap: 8,
                }}
              >
                <Text style={{ fontSize: 15, opacity: 0.5 }}>🔍</Text>
                <TextInput
                  value={search}
                  onChangeText={setSearch}
                  placeholder="Search messages…"
                  placeholderTextColor={Colors.textMuted}
                  style={{ flex: 1, fontSize: 14, color: Colors.text }}
                />
              </View>
            </View>

            {/* Conversation list */}
            {filtered.map((conv) => (
              <Pressable
                key={conv.id}
                style={({ pressed }) => ({
                  flexDirection: "row",
                  alignItems: "center",
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  gap: 12,
                  backgroundColor: pressed ? Colors.card : "transparent",
                })}
              >
                {/* Avatar */}
                <View style={{ position: "relative" }}>
                  <LinearGradient
                    colors={conv.gradient}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={{ width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center" }}
                  >
                    <Text style={{ fontSize: 24 }}>
                      {["😊", "😎", "🥰", "😍", "🌈", "✨"][parseInt(conv.id) % 6]}
                    </Text>
                  </LinearGradient>
                  {conv.online && (
                    <View
                      style={{
                        position: "absolute",
                        bottom: 1,
                        right: 1,
                        width: 14,
                        height: 14,
                        borderRadius: 7,
                        backgroundColor: "#22c55e",
                        borderWidth: 2,
                        borderColor: Colors.background,
                      }}
                    />
                  )}
                </View>

                {/* Content */}
                <View style={{ flex: 1, gap: 3 }}>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                    <Text style={{ fontSize: 15, fontWeight: conv.unread > 0 ? "800" : "600", color: Colors.text }}>
                      {conv.name}
                    </Text>
                    <Text style={{ fontSize: 12, color: conv.unread > 0 ? Colors.primary : Colors.textMuted, fontWeight: "600" }}>
                      {conv.time}
                    </Text>
                  </View>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                    <Text
                      style={{
                        fontSize: 13,
                        color: conv.unread > 0 ? Colors.text : Colors.textMuted,
                        fontWeight: conv.unread > 0 ? "600" : "400",
                        flex: 1,
                      }}
                      numberOfLines={1}
                    >
                      {conv.lastMsg}
                    </Text>
                    {conv.unread > 0 && (
                      <LinearGradient
                        colors={[Colors.primary, Colors.accent]}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                        style={{
                          width: 22,
                          height: 22,
                          borderRadius: 11,
                          alignItems: "center",
                          justifyContent: "center",
                          marginLeft: 8,
                        }}
                      >
                        <Text style={{ color: "#fff", fontSize: 11, fontWeight: "800" }}>{conv.unread}</Text>
                      </LinearGradient>
                    )}
                  </View>
                </View>
              </Pressable>
            ))}
          </View>
        )}
        <View style={{ height: 32 }} />
      </ScrollView>
    </View>
  );
}
