import React, { useState } from "react";
import { View, Text, TextInput, Pressable, ScrollView } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";

const POST_TYPES = [
  { id: "photo", label: "Photo", icon: "📷" },
  { id: "video", label: "Video", icon: "🎬" },
  { id: "text", label: "Text", icon: "✍️" },
  { id: "story", label: "Story", icon: "✨" },
];

const MOOD_TAGS = ["💕 Romantic", "😄 Fun", "🌈 Pride", "🔥 Spicy", "💫 Vibe", "🌙 Late night"];

export default function PostScreen() {
  const [activeType, setActiveType] = useState("photo");
  const [caption, setCaption] = useState("");
  const [selectedMoods, setSelectedMoods] = useState<string[]>([]);

  const toggleMood = (mood: string) => {
    setSelectedMoods((prev) =>
      prev.includes(mood) ? prev.filter((m) => m !== mood) : [...prev, mood]
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        {/* Post type selector */}
        <View style={{ flexDirection: "row", gap: 10, marginBottom: 24 }}>
          {POST_TYPES.map((type) => {
            const isActive = activeType === type.id;
            return (
              <Pressable key={type.id} onPress={() => setActiveType(type.id)} style={{ flex: 1 }}>
                {isActive ? (
                  <LinearGradient
                    colors={[Colors.primary, Colors.accent]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={{ borderRadius: 16, padding: 12, alignItems: "center", gap: 4 }}
                  >
                    <Text style={{ fontSize: 22 }}>{type.icon}</Text>
                    <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>{type.label}</Text>
                  </LinearGradient>
                ) : (
                  <View
                    style={{
                      borderRadius: 16,
                      padding: 12,
                      alignItems: "center",
                      gap: 4,
                      backgroundColor: Colors.card,
                      borderWidth: 1,
                      borderColor: Colors.border,
                    }}
                  >
                    <Text style={{ fontSize: 22 }}>{type.icon}</Text>
                    <Text style={{ color: Colors.textMuted, fontSize: 11, fontWeight: "600" }}>{type.label}</Text>
                  </View>
                )}
              </Pressable>
            );
          })}
        </View>

        {/* Media upload area */}
        <Pressable
          style={({ pressed }) => ({
            height: 220,
            borderRadius: 24,
            overflow: "hidden",
            marginBottom: 20,
            opacity: pressed ? 0.9 : 1,
          })}
        >
          <LinearGradient
            colors={[Colors.card, Colors.border]}
            style={{
              flex: 1,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 2,
              borderRadius: 24,
              borderColor: Colors.border,
              borderStyle: "dashed",
              gap: 10,
            }}
          >
            <View
              style={{
                width: 64,
                height: 64,
                borderRadius: 32,
                backgroundColor: Colors.surface,
                alignItems: "center",
                justifyContent: "center",
                shadowColor: Colors.primary,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.15,
                shadowRadius: 10,
                elevation: 4,
              }}
            >
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{ width: 64, height: 64, borderRadius: 32, alignItems: "center", justifyContent: "center" }}
              >
                <Text style={{ fontSize: 28, color: "#fff" }}>+</Text>
              </LinearGradient>
            </View>
            <Text style={{ color: Colors.text, fontSize: 15, fontWeight: "700" }}>Add media</Text>
            <Text style={{ color: Colors.textMuted, fontSize: 13 }}>Tap to upload from camera or gallery</Text>
          </LinearGradient>
        </Pressable>

        {/* Caption input */}
        <View
          style={{
            backgroundColor: Colors.surface,
            borderRadius: 20,
            padding: 16,
            borderWidth: 1,
            borderColor: Colors.border,
            marginBottom: 20,
          }}
        >
          <TextInput
            value={caption}
            onChangeText={setCaption}
            placeholder="Write a caption… 💬"
            placeholderTextColor={Colors.textMuted}
            multiline
            numberOfLines={4}
            style={{
              fontSize: 15,
              color: Colors.text,
              lineHeight: 22,
              minHeight: 90,
              textAlignVertical: "top",
            }}
          />
          <View style={{ flexDirection: "row", justifyContent: "flex-end", marginTop: 8 }}>
            <Text style={{ fontSize: 12, color: Colors.textMuted }}>{caption.length}/500</Text>
          </View>
        </View>

        {/* Mood tags */}
        <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text, marginBottom: 10 }}>
          Set the vibe
        </Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
          {MOOD_TAGS.map((mood) => {
            const isSelected = selectedMoods.includes(mood);
            return (
              <Pressable key={mood} onPress={() => toggleMood(mood)}>
                {isSelected ? (
                  <LinearGradient
                    colors={[Colors.secondary, Colors.rose]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 }}
                  >
                    <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{mood}</Text>
                  </LinearGradient>
                ) : (
                  <View
                    style={{
                      paddingHorizontal: 14,
                      paddingVertical: 8,
                      borderRadius: 20,
                      borderWidth: 1.5,
                      borderColor: Colors.border,
                      backgroundColor: Colors.card,
                    }}
                  >
                    <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{mood}</Text>
                  </View>
                )}
              </Pressable>
            );
          })}
        </View>

        {/* Post button */}
        <Pressable
          style={({ pressed }) => ({
            opacity: pressed ? 0.85 : 1,
            transform: [{ scale: pressed ? 0.97 : 1 }],
          })}
        >
          <LinearGradient
            colors={[Colors.primary, Colors.accent]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={{
              borderRadius: 20,
              paddingVertical: 18,
              alignItems: "center",
              shadowColor: Colors.primary,
              shadowOffset: { width: 0, height: 6 },
              shadowOpacity: 0.4,
              shadowRadius: 14,
              elevation: 8,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 16, fontWeight: "800", letterSpacing: 0.5 }}>
              Share Post ✨
            </Text>
          </LinearGradient>
        </Pressable>
      </ScrollView>
    </View>
  );
}
