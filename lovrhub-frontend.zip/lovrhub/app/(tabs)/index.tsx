import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Dimensions,
  ImageBackground,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get("window");
const CARD_W = SCREEN_W - 32;
const CARD_H = SCREEN_H * 0.54;

// Mock data for profile cards
const MOCK_PROFILES = [
  {
    id: "1",
    name: "Alex",
    age: 26,
    distance: "2 km",
    intent: "Dating",
    bio: "Coffee addict. Architecture nerd. Looking for someone to get lost with 🗺️",
    tags: ["🎵 Music", "☕ Coffee", "✈️ Travel"],
    gradient: [Colors.secondary, Colors.rose] as [string, string],
    verified: true,
    online: true,
  },
  {
    id: "2",
    name: "Jordan",
    age: 29,
    distance: "5 km",
    intent: "Friends",
    bio: "Freelance photographer. Dog parent. Probably at a rooftop right now.",
    tags: ["📸 Photography", "🐶 Dogs", "🌅 Sunsets"],
    gradient: [Colors.violet, "#6BD4FF"] as [string, string],
    verified: true,
    online: false,
  },
  {
    id: "3",
    name: "Sam",
    age: 24,
    distance: "8 km",
    intent: "LGBTQ+",
    bio: "Queer joy enthusiast. Bookworm. She/they. Here for good vibes.",
    tags: ["📚 Books", "🌈 Pride", "🎨 Art"],
    gradient: [Colors.primary, Colors.accent] as [string, string],
    verified: false,
    online: true,
  },
];

const INTENT_COLORS: Record<string, string> = {
  Dating: Colors.primary,
  Friends: Colors.violet,
  Hookups: Colors.accent,
  "LGBTQ+": Colors.rose,
};

function ProfileCard({ profile, index }: { profile: typeof MOCK_PROFILES[0]; index: number }) {
  const [liked, setLiked] = useState(false);

  return (
    <View
      style={{
        width: CARD_W,
        height: CARD_H,
        borderRadius: 28,
        overflow: "hidden",
        marginBottom: 16,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.15,
        shadowRadius: 20,
        elevation: 10,
      }}
    >
      {/* Card background */}
      <LinearGradient
        colors={profile.gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ flex: 1 }}
      >
        {/* Avatar placeholder */}
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <View
            style={{
              width: 110,
              height: 110,
              borderRadius: 55,
              backgroundColor: "rgba(255,255,255,0.3)",
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 3,
              borderColor: "rgba(255,255,255,0.6)",
            }}
          >
            <Text style={{ fontSize: 52 }}>
              {["😊", "😎", "🥰"][index % 3]}
            </Text>
          </View>
        </View>

        {/* Bottom overlay */}
        <LinearGradient
          colors={["transparent", "rgba(0,0,0,0.65)"]}
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            padding: 20,
            paddingTop: 60,
          }}
        >
          {/* Status badges */}
          <View style={{ flexDirection: "row", gap: 6, marginBottom: 8 }}>
            <View
              style={{
                backgroundColor: INTENT_COLORS[profile.intent] || Colors.primary,
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: 12,
              }}
            >
              <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700", letterSpacing: 0.3 }}>
                {profile.intent}
              </Text>
            </View>
            {profile.online && (
              <View
                style={{
                  backgroundColor: "#22c55e",
                  paddingHorizontal: 10,
                  paddingVertical: 4,
                  borderRadius: 12,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: "#fff" }} />
                <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>Online</Text>
              </View>
            )}
            {profile.verified && (
              <View
                style={{
                  backgroundColor: "#3b82f6",
                  width: 24,
                  height: 24,
                  borderRadius: 12,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text style={{ color: "#fff", fontSize: 12 }}>✓</Text>
              </View>
            )}
          </View>

          <Text style={{ color: "#fff", fontSize: 24, fontWeight: "800", letterSpacing: -0.3 }}>
            {profile.name}, {profile.age}
          </Text>
          <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 13, marginTop: 2 }}>
            📍 {profile.distance} away
          </Text>
          <Text
            style={{ color: "rgba(255,255,255,0.9)", fontSize: 14, marginTop: 6, lineHeight: 20 }}
            numberOfLines={2}
          >
            {profile.bio}
          </Text>

          {/* Tags */}
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
            {profile.tags.map((tag) => (
              <View
                key={tag}
                style={{
                  backgroundColor: "rgba(255,255,255,0.2)",
                  paddingHorizontal: 10,
                  paddingVertical: 4,
                  borderRadius: 10,
                  borderWidth: 1,
                  borderColor: "rgba(255,255,255,0.3)",
                }}
              >
                <Text style={{ color: "#fff", fontSize: 11, fontWeight: "600" }}>{tag}</Text>
              </View>
            ))}
          </View>
        </LinearGradient>
      </LinearGradient>
    </View>
  );
}

function ActionButtons() {
  return (
    <View style={{ flexDirection: "row", justifyContent: "center", gap: 16, paddingVertical: 16 }}>
      {/* Pass */}
      <Pressable
        style={({ pressed }) => ({
          width: 58,
          height: 58,
          borderRadius: 29,
          backgroundColor: Colors.surface,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1.5,
          borderColor: Colors.border,
          opacity: pressed ? 0.7 : 1,
          transform: [{ scale: pressed ? 0.93 : 1 }],
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 3 },
          shadowOpacity: 0.1,
          shadowRadius: 8,
          elevation: 4,
        })}
      >
        <Text style={{ fontSize: 24 }}>✕</Text>
      </Pressable>

      {/* Super like */}
      <Pressable
        style={({ pressed }) => ({
          width: 52,
          height: 52,
          borderRadius: 26,
          backgroundColor: Colors.surface,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1.5,
          borderColor: "#FFD166",
          opacity: pressed ? 0.7 : 1,
          transform: [{ scale: pressed ? 0.93 : 1 }],
        })}
      >
        <Text style={{ fontSize: 20 }}>⭐</Text>
      </Pressable>

      {/* Like */}
      <Pressable
        style={({ pressed }) => ({
          width: 58,
          height: 58,
          borderRadius: 29,
          opacity: pressed ? 0.85 : 1,
          transform: [{ scale: pressed ? 0.93 : 1 }],
          shadowColor: Colors.primary,
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.4,
          shadowRadius: 10,
          elevation: 6,
        })}
      >
        <LinearGradient
          colors={[Colors.primary, Colors.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ flex: 1, borderRadius: 29, alignItems: "center", justifyContent: "center" }}
        >
          <Text style={{ fontSize: 26 }}>♥</Text>
        </LinearGradient>
      </Pressable>

      {/* Boost */}
      <Pressable
        style={({ pressed }) => ({
          width: 52,
          height: 52,
          borderRadius: 26,
          backgroundColor: Colors.surface,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1.5,
          borderColor: Colors.violet,
          opacity: pressed ? 0.7 : 1,
          transform: [{ scale: pressed ? 0.93 : 1 }],
        })}
      >
        <Text style={{ fontSize: 20 }}>⚡</Text>
      </Pressable>

      {/* Message */}
      <Pressable
        style={({ pressed }) => ({
          width: 58,
          height: 58,
          borderRadius: 29,
          backgroundColor: Colors.surface,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1.5,
          borderColor: Colors.border,
          opacity: pressed ? 0.7 : 1,
          transform: [{ scale: pressed ? 0.93 : 1 }],
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 3 },
          shadowOpacity: 0.1,
          shadowRadius: 8,
          elevation: 4,
        })}
      >
        <Text style={{ fontSize: 22 }}>💬</Text>
      </Pressable>
    </View>
  );
}

export default function DiscoverScreen() {
  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentContainerStyle={{ padding: 16, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Today's match banner */}
        <Pressable
          style={({ pressed }) => ({
            opacity: pressed ? 0.9 : 1,
            marginBottom: 16,
          })}
        >
          <LinearGradient
            colors={[Colors.violet, Colors.rose, Colors.accent]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={{
              borderRadius: 18,
              padding: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <View>
              <Text style={{ color: "#fff", fontSize: 12, fontWeight: "600", opacity: 0.85 }}>
                ✨ TODAY'S SPOTLIGHT
              </Text>
              <Text style={{ color: "#fff", fontSize: 17, fontWeight: "800", marginTop: 2 }}>
                3 new people near you!
              </Text>
            </View>
            <View
              style={{
                backgroundColor: "rgba(255,255,255,0.25)",
                paddingHorizontal: 14,
                paddingVertical: 8,
                borderRadius: 14,
              }}
            >
              <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>View →</Text>
            </View>
          </LinearGradient>
        </Pressable>

        {/* Profile cards */}
        {MOCK_PROFILES.map((profile, index) => (
          <View key={profile.id} style={{ alignItems: "center" }}>
            <ProfileCard profile={profile} index={index} />
            <ActionButtons />
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
