# Lovrhub — Frontend Foundation

## Stack
- Expo SDK 51 + Expo Router (file-based routing)
- React Native 0.74
- TypeScript (strict)
- NativeWind v4 (TailwindCSS for React Native)
- React Navigation (via Expo Router)

## Color Palette
| Token       | Hex       | Usage                        |
|-------------|-----------|------------------------------|
| Primary     | #E63946   | CTAs, active states, badges  |
| Secondary   | #F7A1C4   | Gradients, soft accents      |
| Accent      | #FF8C6B   | Gradient endpoints, warmth   |
| Rose        | #FF6B9D   | LGBTQ / pride accents        |
| Violet      | #B06BFF   | Cool accent / friends intent |
| Background  | #FFF8F5   | App background               |
| Text        | #2B2B2B   | Primary text                 |

## Project Structure
```
lovrhub/
├── app/
│   ├── _layout.tsx          # Root layout (GestureHandler + SafeArea)
│   └── (tabs)/
│       ├── _layout.tsx      # Tab layout with custom tab bar
│       ├── index.tsx        # Discover screen
│       ├── explore.tsx      # Explore / feed screen
│       ├── post.tsx         # Create post screen
│       ├── connections.tsx  # Messages / matches screen
│       └── profile.tsx      # Instagram-style profile
├── components/
│   └── TopNavBar.tsx        # Top nav with filter pills
├── constants/
│   └── theme.ts             # All colors, spacing, typography
├── global.css               # NativeWind / Tailwind entry
├── tailwind.config.js
├── babel.config.js
└── metro.config.js
```

## Setup & Run

```bash
# Install dependencies
npm install

# Start Expo dev server
npx expo start

# Run on iOS
npx expo start --ios

# Run on Android
npx expo start --android
```

## Key Design Decisions
- **Custom tab bar** with floating gradient "+" button for Post
- **Discovery filter pills** (All / Dating / Friends / Hookups / LGBTQ+) in TopNavBar
- **Gradient-heavy** profile cards, stories, highlights — warm & colorful
- **Pride-inclusive** intent system (LGBTQ+ as first-class filter)
- All gradients use `expo-linear-gradient` for native performance
- `expo-router` file-based routing = no manual navigator setup
- Fully typed with TypeScript strict mode
