import React from "react";
import { View, Text, Pressable, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { usePathname } from "expo-router";
import { Colors } from "@constants/theme";

const SCREEN_TITLES: Record<string, string> = {
  "/":            "discover",
  "/explore":     "explore",
  "/post":        "new post",
  "/connections": "messages",
  "/profile":     "profile",
};

function NotifBadge() {
  return (
    <View style={{ position: "absolute", top: -2, right: -2, width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.primary, borderWidth: 1.5, borderColor: Colors.surface }} />
  );
}

export default function TopNavBar() {
  const insets = useSafeAreaInsets();
  const pathname = usePathname();
  const screenTitle = SCREEN_TITLES[pathname] ?? "lovrhub";
  const isHome = pathname === "/";
  const isProfile = pathname === "/profile";

  return (
    <View
      style={{
        paddingTop: insets.top,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.border,
      }}
    >
      <View
        style={{
          height: 56,
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          justifyContent: "space-between",
        }}
      >
        {/* Left slot */}
        <View style={{ width: 80, alignItems: "flex-start" }}>
          {isHome ? (
            // Lovrhub logo wordmark on discover screen
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{ width: 30, height: 30, borderRadius: 9, alignItems: "center", justifyContent: "center" }}
              >
                <Text style={{ fontSize: 16 }}>🔥</Text>
              </LinearGradient>
            </View>
          ) : (
            <Pressable
              hitSlop={10}
              style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1 })}
            >
              <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
            </Pressable>
          )}
        </View>

        {/* Center title */}
        <View style={{ flex: 1, alignItems: "center" }}>
          {isHome ? (
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: "800",
                  letterSpacing: -0.5,
                  color: Colors.text,
                }}
              >
                lovr
              </Text>
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={{ borderRadius: 4, paddingHorizontal: 3, paddingVertical: 1 }}
              >
                <Text style={{ fontSize: 22, fontWeight: "800", letterSpacing: -0.5, color: "#fff" }}>
                  hub
                </Text>
              </LinearGradient>
            </View>
          ) : (
            <Text
              style={{
                fontSize: 16,
                fontWeight: "700",
                letterSpacing: 0.5,
                textTransform: "uppercase",
                color: Colors.text,
              }}
            >
              {screenTitle}
            </Text>
          )}
        </View>

        {/* Right slot */}
        <View style={{ width: 80, flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 8 }}>
          {isHome && (
            <>
              <Pressable
                hitSlop={8}
                style={({ pressed }) => ({
                  opacity: pressed ? 0.6 : 1,
                  width: 36,
                  height: 36,
                  borderRadius: 18,
                  backgroundColor: Colors.card,
                  alignItems: "center",
                  justifyContent: "center",
                })}
              >
                <Text style={{ fontSize: 16 }}>⚙</Text>
              </Pressable>
            </>
          )}

          {(pathname === "/connections") && (
            <Pressable
              hitSlop={8}
              style={({ pressed }) => ({
                opacity: pressed ? 0.6 : 1,
                width: 36,
                height: 36,
                borderRadius: 18,
                backgroundColor: Colors.card,
                alignItems: "center",
                justifyContent: "center",
              })}
            >
              <Text style={{ fontSize: 18 }}>✏️</Text>
            </Pressable>
          )}

          {/* Notification bell */}
          <Pressable
            hitSlop={8}
            style={({ pressed }) => ({
              opacity: pressed ? 0.6 : 1,
              width: 36,
              height: 36,
              borderRadius: 18,
              backgroundColor: Colors.card,
              alignItems: "center",
              justifyContent: "center",
            })}
          >
            <View>
              <Text style={{ fontSize: 16 }}>🔔</Text>
              <NotifBadge />
            </View>
          </Pressable>
        </View>
      </View>

      {/* Discover filter pills on home */}
      {isHome && <DiscoverFilterBar />}
    </View>
  );
}

const FILTERS = ["All", "Dating", "Friends", "Hookups", "LGBTQ+"];

function DiscoverFilterBar() {
  const [active, setActive] = React.useState("All");

  return (
    <View
      style={{
        flexDirection: "row",
        paddingHorizontal: 14,
        paddingBottom: 10,
        paddingTop: 4,
        gap: 8,
      }}
    >
      {FILTERS.map((f) => {
        const isActive = active === f;
        return (
          <Pressable
            key={f}
            onPress={() => setActive(f)}
            style={({ pressed }) => ({
              opacity: pressed ? 0.75 : 1,
            })}
          >
            {isActive ? (
              <LinearGradient
                colors={f === "LGBTQ+" ? [Colors.violet, Colors.rose] : [Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{
                  paddingHorizontal: 14,
                  paddingVertical: 6,
                  borderRadius: 20,
                }}
              >
                <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700", letterSpacing: 0.2 }}>{f}</Text>
              </LinearGradient>
            ) : (
              <View
                style={{
                  paddingHorizontal: 14,
                  paddingVertical: 6,
                  borderRadius: 20,
                  backgroundColor: Colors.card,
                  borderWidth: 1,
                  borderColor: Colors.border,
                }}
              >
                <Text style={{ color: Colors.textSecondary, fontSize: 12, fontWeight: "600", letterSpacing: 0.2 }}>{f}</Text>
              </View>
            )}
          </Pressable>
        );
      })}
    </View>
  );
}
