export const Colors = {
  primary: "#E63946",
  primaryLight: "#FF5A66",
  primaryDark: "#C0202E",
  secondary: "#F7A1C4",
  secondaryLight: "#FFC4DC",
  secondaryDark: "#E07AA0",
  accent: "#FF8C6B",
  accentLight: "#FFAA8A",
  accentDark: "#E06A48",

  // Extended palette
  rose: "#FF6B9D",
  violet: "#B06BFF",
  sky: "#6BD4FF",
  gold: "#FFD166",
  mint: "#6BFFB8",

  // Rainbow / Pride gradient stops
  pride: ["#FF6B6B", "#FF8C6B", "#FFD166", "#6BFF9E", "#6BD4FF", "#B06BFF", "#FF6B9D"],

  background: "#FFF8F5",
  surface: "#FFFFFF",
  card: "#FFF0EC",
  border: "#F0D9D4",
  muted: "#9B8A87",

  text: "#2B2B2B",
  textSecondary: "#6B5E5B",
  textMuted: "#9B8A87",
  textInverse: "#FFFFFF",

  // Gradient presets
  gradients: {
    primary: ["#E63946", "#FF8C6B"],
    secondary: ["#F7A1C4", "#FF6B9D"],
    warm: ["#FF8C6B", "#FFD166"],
    cool: ["#B06BFF", "#6BD4FF"],
    sunset: ["#E63946", "#FF8C6B", "#FFD166"],
    aurora: ["#B06BFF", "#FF6B9D", "#FF8C6B"],
    pride: ["#FF6B6B", "#FF8C6B", "#FFD166", "#6BFFB8", "#6BD4FF", "#B06BFF"],
  },
} as const;

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  "2xl": 32,
  "3xl": 48,
  "4xl": 64,
} as const;

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  "2xl": 32,
  full: 9999,
} as const;

export const Typography = {
  display: { fontSize: 36, fontWeight: "800" as const, letterSpacing: -1 },
  h1: { fontSize: 28, fontWeight: "700" as const, letterSpacing: -0.5 },
  h2: { fontSize: 22, fontWeight: "700" as const, letterSpacing: -0.3 },
  h3: { fontSize: 18, fontWeight: "600" as const },
  body: { fontSize: 15, fontWeight: "400" as const, lineHeight: 22 },
  bodyBold: { fontSize: 15, fontWeight: "600" as const },
  caption: { fontSize: 12, fontWeight: "400" as const },
  label: { fontSize: 11, fontWeight: "600" as const, letterSpacing: 0.5 },
} as const;
