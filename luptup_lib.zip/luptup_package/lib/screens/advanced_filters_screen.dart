import 'package:flutter/material.dart';

class AdvancedFiltersScreen extends StatelessWidget {
  const AdvancedFiltersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {},
                    child: const Icon(
                      Icons.arrow_back_ios,
                      color: Color(0xFF9B5CFF),
                      size: 20,
                    ),
                  ),
                  const Expanded(
                    child: Text(
                      'Advanced Filters',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: const Text(
                      'Reset',
                      style: TextStyle(
                        color: Color(0xFF9B5CFF),
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(height: 1, color: const Color(0xFF2A2A40)),

            // Scrollable content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // I'm looking for
                    const Text(
                      "I'm looking for",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        _GenderChip(label: 'Women', isSelected: false),
                        const SizedBox(width: 8),
                        _GenderChip(label: 'Men', isSelected: false),
                        const SizedBox(width: 8),
                        _GenderChip(label: 'Everyone', isSelected: true),
                      ],
                    ),

                    const SizedBox(height: 20),

                    // Relationship Goals
                    const Text(
                      'Relationship Goals',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _DropdownField(value: 'Serious Relationship'),

                    const SizedBox(height: 20),

                    // Age Range
                    const Text(
                      'Age Range',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('21',
                            style: TextStyle(
                                color: Colors.white, fontSize: 12)),
                        Text('35+',
                            style: TextStyle(
                                color: Colors.white, fontSize: 12)),
                      ],
                    ),
                    RangeSlider(
                      values: const RangeValues(21, 35),
                      min: 18,
                      max: 50,
                      activeColor: const Color(0xFF7B2FFF),
                      inactiveColor: const Color(0xFF2A2A40),
                      onChanged: (_) {},
                    ),

                    const SizedBox(height: 20),

                    // Height Range
                    const Text(
                      'Height Range',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('150 cm',
                            style: TextStyle(
                                color: Colors.white, fontSize: 12)),
                        Text('190 cm',
                            style: TextStyle(
                                color: Colors.white, fontSize: 12)),
                      ],
                    ),
                    RangeSlider(
                      values: const RangeValues(150, 190),
                      min: 140,
                      max: 220,
                      activeColor: const Color(0xFF7B2FFF),
                      inactiveColor: const Color(0xFF2A2A40),
                      onChanged: (_) {},
                    ),

                    const SizedBox(height: 20),

                    // Education
                    const Text(
                      'Education',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _DropdownField(value: "Bachelor's Degree"),

                    const SizedBox(height: 20),

                    // Lifestyle
                    const Text(
                      'Lifestyle',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: const [
                        _LifestyleChip(label: 'Non-smoker'),
                        _LifestyleChip(label: 'Socially'),
                        _LifestyleChip(label: 'Vegetarian'),
                        _LifestyleChip(label: 'Sometimes drinks'),
                      ],
                    ),

                    const SizedBox(height: 20),

                    // More Filters
                    const Text(
                      'More Filters',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _FilterDropdownRow(label: 'Kids', value: 'No'),
                    const SizedBox(height: 8),
                    _FilterDropdownRow(label: 'Religion', value: 'Spiritual'),

                    const SizedBox(height: 12),
                  ],
                ),
              ),
            ),

            // Apply button
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
              child: SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF7B2FFF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'Apply Filters',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GenderChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  const _GenderChip({required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFF7B2FFF) : const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(18),
        border: isSelected
            ? null
            : Border.all(color: const Color(0xFF2A2A40)),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white60,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _DropdownField extends StatelessWidget {
  final String value;
  const _DropdownField({required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
              ),
            ),
          ),
          const Icon(
            Icons.keyboard_arrow_down,
            color: Colors.white54,
            size: 20,
          ),
        ],
      ),
    );
  }
}

class _LifestyleChip extends StatelessWidget {
  final String label;
  const _LifestyleChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: const Color(0xFF9B5CFF), width: 1),
      ),
      child: Center(
        child: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _FilterDropdownRow extends StatelessWidget {
  final String label;
  final String value;
  const _FilterDropdownRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white60,
              fontSize: 13,
            ),
          ),
          const SizedBox(width: 6),
          const Icon(
            Icons.keyboard_arrow_down,
            color: Colors.white54,
            size: 20,
          ),
        ],
      ),
    );
  }
}
