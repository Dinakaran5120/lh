import 'package:flutter/material.dart';

class AllGroupsScreen extends StatelessWidget {
  const AllGroupsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {},
                    child: const Icon(Icons.arrow_back_ios,
                        color: Color(0xFF9B5CFF), size: 20),
                  ),
                  const Expanded(
                    child: Text(
                      'All Groups',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const Icon(Icons.search, color: Colors.white, size: 22),
                ],
              ),
            ),

            // Category chips
            SizedBox(
              height: 36,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  _CategoryChip(label: 'Travel', isSelected: true),
                  const SizedBox(width: 8),
                  _CategoryChip(label: 'Adventure', isSelected: false),
                  const SizedBox(width: 8),
                  _CategoryChip(label: 'Book Readers', isSelected: false),
                  const SizedBox(width: 8),
                  _CategoryChip(label: 'Gym Freak', isSelected: false),
                  const SizedBox(width: 8),
                  _CategoryChip(label: 'Night Owl', isSelected: false),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // Groups list
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: const [
                  _AllGroupRow(name: 'Travel Buddies ✈', members: '1.2K Members', color: Color(0xFF1A3040)),
                  _AllGroupRow(name: 'Wanderlust Souls 🌍', members: '987 Members', color: Color(0xFF1A2A30)),
                  _AllGroupRow(name: 'Backpackers Unite 🎒', members: '756 Members', color: Color(0xFF2A1A10)),
                  _AllGroupRow(name: 'Hidden Gems 🗺', members: '642 Members', color: Color(0xFF1A1A30)),
                  _AllGroupRow(name: 'Solo Travelers 🧭', members: '523 Members', color: Color(0xFF1A2A20)),
                  _AllGroupRow(name: 'Road Trip Crew 🚗', members: '812 Members', color: Color(0xFF2A2A10)),
                  _AllGroupRow(name: 'Beach Lovers 🏖', members: '678 Members', color: Color(0xFF1A2A3A)),
                  _AllGroupRow(name: 'Mountain Explorers ⛰', members: '589 Members', color: Color(0xFF1A1A20)),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AllGroupRow extends StatelessWidget {
  final String name;
  final String members;
  final Color color;

  const _AllGroupRow({
    required this.name,
    required this.members,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          // Thumbnail
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Container(
              width: 60,
              height: 60,
              color: color,
              child: const Icon(Icons.group, color: Colors.white38, size: 28),
            ),
          ),
          const SizedBox(width: 12),

          // Name + members
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  members,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),

          // Join button
          SizedBox(
            height: 32,
            child: ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF7B2FFF),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 18),
                elevation: 0,
              ),
              child: const Text(
                'Join',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  const _CategoryChip({required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFF7B2FFF) : const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(17),
        border: isSelected ? null : Border.all(color: const Color(0xFF2A2A40)),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white60,
            fontSize: 13,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ),
    );
  }
}
