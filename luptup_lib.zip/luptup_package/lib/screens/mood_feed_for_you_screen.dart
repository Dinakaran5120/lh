import 'package:flutter/material.dart';

class MoodFeedForYouScreen extends StatelessWidget {
  const MoodFeedForYouScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            _TopAppBar(),
            _FeedTabBar(activeTab: 0),
            _ComposeBar(),
            Container(height: 1, color: const Color(0xFF2A2A40)),
            const Expanded(child: _ForYouPostList()),
          ],
        ),
      ),
      bottomNavigationBar: _BottomNavBar(activeIndex: 0),
    );
  }
}

// ── Compose bar ───────────────────────────────────────────────────────────────
class _ComposeBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: const BoxDecoration(
                color: Color(0xFF2A2A40), shape: BoxShape.circle),
            child: const Icon(Icons.person,
                color: Colors.white38, size: 20),
          ),
          const SizedBox(width: 10),
          _ComposeBtn(icon: Icons.text_fields, label: 'Text'),
          const SizedBox(width: 8),
          _ComposeBtn(icon: Icons.image_outlined, label: 'Photo'),
          const SizedBox(width: 8),
          _ComposeBtn(icon: Icons.videocam_outlined, label: 'Video'),
          const Spacer(),
          const Icon(Icons.tune,
              color: Color(0xFF9B5CFF), size: 20),
        ],
      ),
    );
  }
}

class _ComposeBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  const _ComposeBtn({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
          color: const Color(0xFF1E1E32),
          borderRadius: BorderRadius.circular(16)),
      child: Row(children: [
        Icon(icon, color: const Color(0xFF9B5CFF), size: 14),
        const SizedBox(width: 5),
        Text(label,
            style: const TextStyle(
                color: Colors.white60, fontSize: 12)),
      ]),
    );
  }
}

// ── For You Post List ─────────────────────────────────────────────────────────
class _ForYouPostList extends StatelessWidget {
  const _ForYouPostList();

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        _FullPostCard(
          creatorName: 'Anaya',
          timeAgo: '2h ago',
          hasMedia: true,
          isLocked: true,
          caption:
              'Chasing sunsets and dreams ✨\nBali, you stole my heart 💜',
          hashtags: '#SunsetLover #BaliDiaries',
          likes: '1,256',
          comments: '86',
          superLikes: '52',
          coins: '230',
          duration: '0:15',
        ),
        _FullPostCard(
          creatorName: 'Kabir',
          timeAgo: '5h ago',
          hasMedia: false,
          isLocked: false,
          caption:
              'A little reminder for your Monday 💪\nYou\'ve got this.',
          hashtags: '',
          likes: '713',
          comments: '35',
          superLikes: '21',
          coins: '90',
          duration: '',
        ),
        SizedBox(height: 80),
      ],
    );
  }
}

class _FullPostCard extends StatelessWidget {
  final String creatorName;
  final String timeAgo;
  final bool hasMedia;
  final bool isLocked;
  final String caption;
  final String hashtags;
  final String likes;
  final String comments;
  final String superLikes;
  final String coins;
  final String duration;

  const _FullPostCard({
    required this.creatorName,
    required this.timeAgo,
    required this.hasMedia,
    required this.isLocked,
    required this.caption,
    required this.hashtags,
    required this.likes,
    required this.comments,
    required this.superLikes,
    required this.coins,
    required this.duration,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Post header
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(
                    color: Color(0xFF2A2A40),
                    shape: BoxShape.circle),
                child: const Icon(Icons.person,
                    color: Colors.white38, size: 22),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Text('$creatorName ✓',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w600)),
                    ]),
                    Text(timeAgo,
                        style: const TextStyle(
                            color: Colors.white38,
                            fontSize: 11)),
                  ],
                ),
              ),
              const Icon(Icons.more_vert,
                  color: Colors.white38, size: 18),
            ],
          ),
        ),

        // Media area
        if (hasMedia)
          Stack(
            children: [
              Container(
                width: double.infinity,
                height: 220,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF2A1040), Color(0xFF3A1A20)],
                  ),
                ),
                child: const Center(
                  child: Icon(Icons.play_circle_outline,
                      color: Colors.white24, size: 60),
                ),
              ),
              if (duration.isNotEmpty)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 3),
                    decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius:
                            BorderRadius.circular(6)),
                    child: Text(duration,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10)),
                  ),
                ),
              if (isLocked)
                Positioned.fill(
                  child: Container(
                    color: Colors.black.withOpacity(0.55),
                    child: const Column(
                      mainAxisAlignment:
                          MainAxisAlignment.center,
                      children: [
                        Icon(Icons.lock,
                            color: Colors.white, size: 32),
                        SizedBox(height: 8),
                        Text('Locked',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight:
                                    FontWeight.w600)),
                        SizedBox(height: 4),
                        Text('Unlock to watch',
                            style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12)),
                      ],
                    ),
                  ),
                ),
            ],
          ),

        // Caption
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(caption,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 14)),
              if (hashtags.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(hashtags,
                    style: const TextStyle(
                        color: Color(0xFF9B5CFF),
                        fontSize: 13)),
              ],
            ],
          ),
        ),

        // Stats row
        Padding(
          padding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 6),
          child: Row(children: [
            _StatBtn(
                icon: Icons.favorite_border,
                value: likes,
                label: ''),
            const SizedBox(width: 16),
            _StatBtn(
                icon: Icons.chat_bubble_outline,
                value: comments,
                label: ''),
            const SizedBox(width: 16),
            _StatBtn(
                icon: Icons.star_border,
                value: superLikes,
                label: 'Super Like'),
            const SizedBox(width: 16),
            _StatBtn(
                icon: Icons.monetization_on_outlined,
                value: coins,
                label: 'Thanks'),
          ]),
        ),

        // Unlock CTA (for locked posts)
        if (isLocked)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Container(
              height: 40,
              decoration: BoxDecoration(
                  color: const Color(0xFF1E1E32),
                  borderRadius: BorderRadius.circular(20)),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(children: [
                const Icon(Icons.lock_outline,
                    color: Colors.white54, size: 16),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text('Support creators you love.',
                      style: TextStyle(
                          color: Colors.white60,
                          fontSize: 12)),
                ),
                SizedBox(
                  height: 28,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          const Color(0xFF7B2FFF),
                      shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12),
                      elevation: 0,
                    ),
                    child: const Text('Send Coins',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 11)),
                  ),
                ),
              ]),
            ),
          ),

        Container(height: 1, color: const Color(0xFF1A1A2E)),
      ],
    );
  }
}

class _StatBtn extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  const _StatBtn(
      {required this.icon,
      required this.value,
      required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: Colors.white54, size: 18),
      const SizedBox(width: 4),
      Text(value,
          style: const TextStyle(
              color: Colors.white54, fontSize: 12)),
      if (label.isNotEmpty) ...[
        const SizedBox(width: 3),
        Text(label,
            style: const TextStyle(
                color: Colors.white38, fontSize: 11)),
      ],
    ]);
  }
}

// ── Shared widgets (same as trending screen) ──────────────────────────────────
class _TopAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 12),
      child: Row(children: [
        Row(children: [
          Container(
            width: 26,
            height: 26,
            decoration: const BoxDecoration(
                color: Color(0xFF7B2FFF),
                shape: BoxShape.circle),
            child: const Icon(Icons.favorite,
                color: Colors.white, size: 13),
          ),
          const SizedBox(width: 6),
          const Text('lup tup',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold)),
        ]),
        const Spacer(),
        Container(
          height: 28,
          padding:
              const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
              color: const Color(0xFF1E1E32),
              borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            Container(
                width: 14,
                height: 14,
                decoration: const BoxDecoration(
                    color: Color(0xFFF5A623),
                    shape: BoxShape.circle)),
            const SizedBox(width: 4),
            const Text('1,542',
                style: TextStyle(
                    color: Color(0xFFF5A623),
                    fontSize: 13,
                    fontWeight: FontWeight.w600)),
            const SizedBox(width: 2),
            const Icon(Icons.add,
                color: Color(0xFF9B5CFF), size: 14),
          ]),
        ),
        const SizedBox(width: 8),
        Stack(children: [
          const Icon(Icons.notifications_outlined,
              color: Colors.white, size: 22),
          Positioned(
            top: 0,
            right: 0,
            child: Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle)),
          ),
        ]),
      ]),
    );
  }
}

class _FeedTabBar extends StatelessWidget {
  final int activeTab;
  const _FeedTabBar({required this.activeTab});

  @override
  Widget build(BuildContext context) {
    final tabs = ['For You', 'Following', 'Trending'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: List.generate(tabs.length, (i) {
          final isActive = i == activeTab;
          return Padding(
            padding: EdgeInsets.only(
                right: i < tabs.length - 1 ? 20 : 0),
            child: Column(children: [
              Text(tabs[i],
                  style: TextStyle(
                      color: isActive
                          ? Colors.white
                          : Colors.white54,
                      fontSize: 14,
                      fontWeight: isActive
                          ? FontWeight.w600
                          : FontWeight.w400)),
              const SizedBox(height: 6),
              Container(
                  height: 2,
                  width: isActive ? 60 : 0,
                  color: const Color(0xFF9B5CFF)),
            ]),
          );
        }),
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  final int activeIndex;
  const _BottomNavBar({required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: const BoxDecoration(
          color: Color(0xFF0D0D1E),
          border: Border(
              top:
                  BorderSide(color: Color(0xFF2A2A40)))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(
              icon: Icons.home,
              label: 'Home',
              isActive: activeIndex == 0),
          _NavItem(
              icon: Icons.explore_outlined,
              label: 'Discover',
              isActive: activeIndex == 1),
          Container(
            width: 44,
            height: 44,
            decoration: const BoxDecoration(
                color: Color(0xFF7B2FFF),
                shape: BoxShape.circle),
            child: const Icon(Icons.add,
                color: Colors.white, size: 24),
          ),
          _NavItemBadge(
              icon: Icons.chat_bubble_outline,
              label: 'Chats',
              badge: '3',
              isActive: activeIndex == 3),
          _NavItem(
              icon: Icons.person_outline,
              label: 'Profile',
              isActive: activeIndex == 4),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  const _NavItem(
      {required this.icon,
      required this.label,
      required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon,
          color: isActive
              ? const Color(0xFF9B5CFF)
              : Colors.white38,
          size: 22),
      const SizedBox(height: 2),
      Text(label,
          style: TextStyle(
              color: isActive
                  ? const Color(0xFF9B5CFF)
                  : Colors.white38,
              fontSize: 10)),
    ]);
  }
}

class _NavItemBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final String badge;
  final bool isActive;
  const _NavItemBadge(
      {required this.icon,
      required this.label,
      required this.badge,
      required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Stack(children: [
        Icon(icon,
            color: isActive
                ? const Color(0xFF9B5CFF)
                : Colors.white38,
            size: 22),
        Positioned(
          top: 0,
          right: 0,
          child: Container(
            width: 14,
            height: 14,
            decoration: const BoxDecoration(
                color: Colors.red, shape: BoxShape.circle),
            child: Center(
                child: Text(badge,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.bold))),
          ),
        ),
      ]),
      const SizedBox(height: 2),
      Text(label,
          style: TextStyle(
              color: isActive
                  ? const Color(0xFF9B5CFF)
                  : Colors.white38,
              fontSize: 10)),
    ]);
  }
}
