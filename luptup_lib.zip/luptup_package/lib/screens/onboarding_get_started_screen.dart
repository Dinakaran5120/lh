import 'package:flutter/material.dart';

class OnboardingGetStartedScreen extends StatelessWidget {
  const OnboardingGetStartedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Header row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Color(0xFF9B5CFF),
                        size: 20,
                      ),
                    ),
                    TextButton(
                      onPressed: () {},
                      child: const Text(
                        'Skip',
                        style: TextStyle(
                          color: Color(0xFF9B5CFF),
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 8),

                // Title block
                const Text(
                  'New Here?',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Let's get you started ",
                      style: TextStyle(
                        color: Color(0xFF9B5CFF),
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Icon(
                      Icons.favorite,
                      color: Color(0xFF9B5CFF),
                      size: 18,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'A few quick steps to help us find\nthe right people for you.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 13,
                    height: 1.5,
                  ),
                ),

                const SizedBox(height: 20),

                // 3D heart illustration with emoji overlays
                SizedBox(
                  width: 120,
                  height: 100,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 88,
                        height: 88,
                        decoration: BoxDecoration(
                          color: const Color(0xFF7B2FFF),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF7B2FFF).withOpacity(0.4),
                              blurRadius: 24,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.favorite,
                          color: Colors.white,
                          size: 44,
                        ),
                      ),
                      const Positioned(
                        top: 0,
                        right: 0,
                        child: Text('👋', style: TextStyle(fontSize: 22)),
                      ),
                      const Positioned(
                        bottom: 4,
                        right: 16,
                        child: Text('😊', style: TextStyle(fontSize: 20)),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // What are you looking for section
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'What are you looking for?',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                const _RadioOptionTile(
                  icon: Icons.people,
                  title: 'Something serious',
                  subtitle: 'Find a meaningful, long-term relationship.',
                  isSelected: false,
                ),
                const SizedBox(height: 8),
                const _RadioOptionTile(
                  icon: Icons.favorite,
                  title: 'Something fun',
                  subtitle: 'Meet new people and enjoy the moment.',
                  isSelected: true,
                ),
                const SizedBox(height: 8),
                const _RadioOptionTile(
                  icon: Icons.group,
                  title: 'New friends',
                  subtitle: 'Make new friends and expand your circle.',
                  isSelected: false,
                ),

                const SizedBox(height: 18),

                // How would you describe yourself
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'How would you describe yourself?',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                Row(
                  children: [
                    _PersonalityChip(label: 'Introvert', isSelected: true),
                    const SizedBox(width: 8),
                    _PersonalityChip(label: 'Ambivert', isSelected: false),
                    const SizedBox(width: 8),
                    _PersonalityChip(label: 'Extrovert', isSelected: false),
                  ],
                ),

                const SizedBox(height: 18),

                // Add photos section
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Add your photos',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Upload at least 2 photos to get better matches.',
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 11,
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                Row(
                  children: [
                    // Add photo slot (dashed)
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1E32),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: const Color(0xFF9B5CFF),
                          width: 1.5,
                          style: BorderStyle.solid,
                        ),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add, color: Color(0xFF9B5CFF), size: 20),
                          Text(
                            'Add Photo',
                            style: TextStyle(
                              color: Color(0xFF9B5CFF),
                              fontSize: 7,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    ...List.generate(4, (i) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: const Color(0xFF1E1E32),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.image_outlined,
                            color: Colors.white24,
                            size: 18,
                          ),
                        ),
                      );
                    }),
                  ],
                ),

                const SizedBox(height: 20),

                // Continue button
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF7B2FFF),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(28),
                      ),
                      elevation: 0,
                    ),
                    child: const Text(
                      'Continue',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                RichText(
                  text: const TextSpan(
                    children: [
                      TextSpan(
                        text: 'Already have an account? ',
                        style: TextStyle(color: Colors.white54, fontSize: 13),
                      ),
                      TextSpan(
                        text: 'Log in',
                        style: TextStyle(
                          color: Color(0xFF9B5CFF),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RadioOptionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool isSelected;

  const _RadioOptionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFF2A1A4A) : const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(12),
        border: isSelected
            ? Border.all(color: const Color(0xFF9B5CFF), width: 1.5)
            : Border.all(color: Colors.transparent),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: const BoxDecoration(
              color: Color(0xFF2A1A4A),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: const Color(0xFF9B5CFF), size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 10,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Container(
            width: 18,
            height: 18,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isSelected ? const Color(0xFF9B5CFF) : Colors.transparent,
              border: Border.all(
                color: isSelected
                    ? const Color(0xFF9B5CFF)
                    : Colors.white38,
                width: 1.5,
              ),
            ),
            child: isSelected
                ? const Icon(Icons.circle, color: Colors.white, size: 8)
                : null,
          ),
        ],
      ),
    );
  }
}

class _PersonalityChip extends StatelessWidget {
  final String label;
  final bool isSelected;

  const _PersonalityChip({required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFF2A1A4A) : const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? const Color(0xFF9B5CFF) : const Color(0xFF2A2A40),
          width: 1.5,
        ),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? const Color(0xFF9B5CFF) : Colors.white70,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
