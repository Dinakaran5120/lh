import 'package:flutter/material.dart';
import 'dart:math' as math;

class MoodFeedFollowingScreen extends StatelessWidget {
  const MoodFeedFollowingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            _TopAppBar(),
            _FeedTabBar(activeTab: 1),
            _StoriesRow(),
            Container(height: 1, color: const Color(0xFF2A2A40)),
            const Expanded(child: _FollowingPostList()),
          ],
        ),
      ),
      bottomNavigationBar: _BottomNavBar(activeIndex: 0),
    );
  }
}

// ── Stories Row ───────────────────────────────────────────────────────────────
class _StoriesRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    const storyNames = ['Anaya', 'Kabir', 'Riya', 'Meera'];

    return SizedBox(
      height: 90,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(
            horizontal: 16, vertical: 8),
        children: [
          // Your Story
          _YourStoryAvatar(),
          const SizedBox(width: 14),
          ...storyNames.map((name) => Padding(
                padding: const EdgeInsets.only(right: 14),
                child: _StoryAvatar(name: name),
              )),
        ],
      ),
    );
  }
}

class _YourStoryAvatar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E32),
            shape: BoxShape.circle,
            border: Border.all(
                color: const Color(0xFF9B5CFF),
                width: 1.5,
                style: BorderStyle.solid),
          ),
          child: const Icon(Icons.add,
              color: Color(0xFF9B5CFF), size: 24),
        ),
        const SizedBox(height: 5),
        const Text('Your Story',
            style:
                TextStyle(color: Colors.white54, fontSize: 10)),
      ],
    );
  }
}

class _StoryAvatar extends StatelessWidget {
  final String name;
  const _StoryAvatar({required this.name});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          children: [
            // Gradient ring
            Container(
              width: 60,
              height: 60,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF9B5CFF),
                      Color(0xFFFF6B9D),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )),
            ),
            Positioned(
              top: 2,
              left: 2,
              right: 2,
              bottom: 2,
              child: Container(
                decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF0D0D1E)),
              ),
            ),
            Positioned(
              top: 3,
              left: 3,
              right: 3,
              bottom: 3,
              child: Container(
                decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF2A2A40)),
                child: const ClipOval(
                  child: Icon(Icons.person,
                      color: Colors.white38, size: 28),
                ),
              ),
            ),
            // Online dot
            Positioned(
              bottom: 2,
              right: 2,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: const Color(0xFF2ECC71),
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: const Color(0xFF0D0D1E),
                      width: 2),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 5),
        Text(name,
            style: const TextStyle(
                color: Colors.white, fontSize: 10)),
      ],
    );
  }
}

// ── Following Post List ───────────────────────────────────────────────────────
class _FollowingPostList extends StatelessWidget {
  const _FollowingPostList();

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        _FollowingPostCard(
          creatorName: 'Anaya',
          timeAgo: '1h ago',
          hasMedia: true,
          caption:
              'Chasing sunsets and dreams ✨💜\n#SunsetLover #BaliDiaries',
          likes: '1,256',
          comments: '86',
          superLikes: '52',
          coins: '230',
          unlockCoins: '30',
          duration: '0:15',
        ),
        _FollowingPostCard(
          creatorName: 'Kabir',
          timeAgo: '3h ago',
          hasMedia: false,
          caption:
              'Monday motivation 💪\nStay focused. Good things take time.',
          likes: '842',
          comments: '42',
          superLikes: '28',
          coins: '120',
          unlockCoins: '0',
          duration: '',
        ),
        SizedBox(height: 80),
      ],
    );
  }
}

class _FollowingPostCard extends StatelessWidget {
  final String creatorName;
  final String timeAgo;
  final bool hasMedia;
  final String caption;
  final String likes;
  final String comments;
  final String superLikes;
  final String coins;
  final String unlockCoins;
  final String duration;

  const _FollowingPostCard({
    required this.creatorName,
    required this.timeAgo,
    required this.hasMedia,
    required this.caption,
    required this.likes,
    required this.comments,
    required this.superLikes,
    required this.coins,
    required this.unlockCoins,
    required this.duration,
  });

  @override
  Widget build(BuildContext context) {
    final bool isLocked = unlockCoins != '0';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(children: [
            Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                  color: Color(0xFF2A2A40),
                  shape: BoxShape.circle),
              child: const Icon(Icons.person,
                  color: Colors.white38, size: 22),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$creatorName ✓',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600)),
                  Text(timeAgo,
                      style: const TextStyle(
                          color: Colors.white38, fontSize: 11)),
                ],
              ),
            ),
            const Icon(Icons.more_horiz,
                color: Colors.white38, size: 20),
          ]),
        ),

        // Media
        if (hasMedia)
          Stack(children: [
            Container(
              width: double.infinity,
              height: 200,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF2A1040), Color(0xFF3A1A20)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: const Center(
                child: Icon(Icons.play_circle_outline,
                    color: Colors.white24, size: 56),
              ),
            ),
            if (duration.isNotEmpty)
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(6)),
                  child: Text(duration,
                      style: const TextStyle(
                          color: Colors.white, fontSize: 10)),
                ),
              ),
            if (isLocked)
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 40,
                  color: Colors.black.withOpacity(0.3),
                ),
              ),
          ]),

        // Caption
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
          child: Text(
            caption,
            style: const TextStyle(
                color: Colors.white70, fontSize: 13, height: 1.4),
          ),
        ),

        // Stats
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            _StatIcon(icon: Icons.favorite_border, value: likes),
            const SizedBox(width: 14),
            _StatIcon(
                icon: Icons.chat_bubble_outline,
                value: comments),
            const SizedBox(width: 14),
            _StatIcon(
                icon: Icons.star_border, value: superLikes),
            const SizedBox(width: 14),
            _StatIcon(
                icon: Icons.monetization_on_outlined,
                value: coins),
          ]),
        ),

        const SizedBox(height: 8),

        // Unlock / Send row
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: isLocked
              ? Container(
                  height: 36,
                  decoration: BoxDecoration(
                      color: const Color(0xFF1E1E32),
                      borderRadius: BorderRadius.circular(18)),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(children: [
                    const Icon(Icons.lock,
                        color: Color(0xFF9B5CFF), size: 14),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                          'Unlock this post and support $creatorName',
                          style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 12)),
                    ),
                    Container(
                      height: 28,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10),
                      decoration: BoxDecoration(
                          color: const Color(0xFF7B2FFF),
                          borderRadius:
                              BorderRadius.circular(14)),
                      child: Row(children: [
                        const Text('🪙',
                            style: TextStyle(fontSize: 12)),
                        const SizedBox(width: 4),
                        Text('$unlockCoins Unlock',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight:
                                    FontWeight.w600)),
                      ]),
                    ),
                  ]),
                )
              : Row(children: [
                  const Icon(Icons.send,
                      color: Colors.white54, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                        'Show some love and send $creatorName thanks',
                        style: const TextStyle(
                            color: Colors.white60,
                            fontSize: 12)),
                  ),
                  Container(
                    height: 28,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                        color: const Color(0xFF1E1E32),
                        borderRadius:
                            BorderRadius.circular(14),
                        border: Border.all(
                            color: const Color(0xFF9B5CFF),
                            width: 1)),
                    child: const Row(children: [
                      Text('🪙',
                          style: TextStyle(fontSize: 12)),
                      SizedBox(width: 4),
                      Text('Send',
                          style: TextStyle(
                              color: Color(0xFF9B5CFF),
                              fontSize: 11,
                              fontWeight: FontWeight.w600)),
                    ]),
                  ),
                ]),
        ),

        Container(height: 1, color: const Color(0xFF1A1A2E)),
      ],
    );
  }
}

class _StatIcon extends StatelessWidget {
  final IconData icon;
  final String value;
  const _StatIcon({required this.icon, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: Colors.white54, size: 17),
      const SizedBox(width: 4),
      Text(value,
          style: const TextStyle(
              color: Colors.white54, fontSize: 12)),
    ]);
  }
}

// ── Shared widgets ────────────────────────────────────────────────────────────
class _TopAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 12),
      child: Row(children: [
        Row(children: [
          Container(
              width: 26,
              height: 26,
              decoration: const BoxDecoration(
                  color: Color(0xFF7B2FFF),
                  shape: BoxShape.circle),
              child: const Icon(Icons.favorite,
                  color: Colors.white, size: 13)),
          const SizedBox(width: 6),
          const Text('lup tup',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold)),
        ]),
        const Spacer(),
        Container(
          height: 28,
          padding:
              const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
              color: const Color(0xFF1E1E32),
              borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            Container(
                width: 14,
                height: 14,
                decoration: const BoxDecoration(
                    color: Color(0xFFF5A623),
                    shape: BoxShape.circle)),
            const SizedBox(width: 4),
            const Text('1,542',
                style: TextStyle(
                    color: Color(0xFFF5A623),
                    fontSize: 13,
                    fontWeight: FontWeight.w600)),
            const SizedBox(width: 2),
            const Icon(Icons.add,
                color: Color(0xFF9B5CFF), size: 14),
          ]),
        ),
        const SizedBox(width: 8),
        Stack(children: [
          const Icon(Icons.notifications_outlined,
              color: Colors.white, size: 22),
          Positioned(
              top: 0,
              right: 0,
              child: Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle))),
        ]),
      ]),
    );
  }
}

class _FeedTabBar extends StatelessWidget {
  final int activeTab;
  const _FeedTabBar({required this.activeTab});

  @override
  Widget build(BuildContext context) {
    final tabs = ['For You', 'Following', 'Trending'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: List.generate(tabs.length, (i) {
          final isActive = i == activeTab;
          return Padding(
            padding: EdgeInsets.only(
                right: i < tabs.length - 1 ? 20 : 0),
            child: Column(children: [
              Text(tabs[i],
                  style: TextStyle(
                      color: isActive
                          ? Colors.white
                          : Colors.white54,
                      fontSize: 14,
                      fontWeight: isActive
                          ? FontWeight.w600
                          : FontWeight.w400)),
              const SizedBox(height: 6),
              Container(
                  height: 2,
                  width: isActive ? 60 : 0,
                  color: const Color(0xFF9B5CFF)),
            ]),
          );
        }),
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  final int activeIndex;
  const _BottomNavBar({required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: const BoxDecoration(
          color: Color(0xFF0D0D1E),
          border: Border(
              top: BorderSide(color: Color(0xFF2A2A40)))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(
              icon: Icons.home,
              label: 'Home',
              isActive: activeIndex == 0),
          _NavItem(
              icon: Icons.explore_outlined,
              label: 'Discover',
              isActive: activeIndex == 1),
          Container(
            width: 44,
            height: 44,
            decoration: const BoxDecoration(
                color: Color(0xFF7B2FFF),
                shape: BoxShape.circle),
            child: const Icon(Icons.add,
                color: Colors.white, size: 24),
          ),
          _NavItemBadge(
              icon: Icons.chat_bubble_outline,
              label: 'Chats',
              badge: '3',
              isActive: activeIndex == 3),
          _NavItem(
              icon: Icons.person_outline,
              label: 'Profile',
              isActive: activeIndex == 4),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  const _NavItem(
      {required this.icon,
      required this.label,
      required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon,
          color: isActive
              ? const Color(0xFF9B5CFF)
              : Colors.white38,
          size: 22),
      const SizedBox(height: 2),
      Text(label,
          style: TextStyle(
              color: isActive
                  ? const Color(0xFF9B5CFF)
                  : Colors.white38,
              fontSize: 10)),
    ]);
  }
}

class _NavItemBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final String badge;
  final bool isActive;
  const _NavItemBadge(
      {required this.icon,
      required this.label,
      required this.badge,
      required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Stack(children: [
        Icon(icon,
            color: isActive
                ? const Color(0xFF9B5CFF)
                : Colors.white38,
            size: 22),
        Positioned(
          top: 0,
          right: 0,
          child: Container(
            width: 14,
            height: 14,
            decoration: const BoxDecoration(
                color: Colors.red, shape: BoxShape.circle),
            child: Center(
                child: Text(badge,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.bold))),
          ),
        ),
      ]),
      const SizedBox(height: 2),
      Text(label,
          style: TextStyle(
              color: isActive
                  ? const Color(0xFF9B5CFF)
                  : Colors.white38,
              fontSize: 10)),
    ]);
  }
}
