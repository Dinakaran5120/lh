import 'package:flutter/material.dart';

class WhatAreYouLookingForScreen extends StatelessWidget {
  const WhatAreYouLookingForScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 16, left: 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                  onPressed: () {},
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Color(0xFF9B5CFF),
                    size: 20,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  Text(
                    'What are you\nlooking for?',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Choose one or more.\nYou can change this anytime.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 13,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 28),

            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 2.2,
                  physics: const NeverScrollableScrollPhysics(),
                  children: const [
                    _OptionCard(
                      title: 'Love',
                      subtitle: 'Relationship',
                      iconData: Icons.favorite,
                      iconBg: Color(0xFF3D1A3A),
                      iconColor: Color(0xFFFF6B9D),
                    ),
                    _OptionCard(
                      title: 'Dating',
                      subtitle: 'Meet dates',
                      iconData: Icons.people,
                      iconBg: Color(0xFF2A1A3D),
                      iconColor: Color(0xFF9B5CFF),
                    ),
                    _OptionCard(
                      title: 'Friendship',
                      subtitle: 'Make friends',
                      iconData: Icons.group,
                      iconBg: Color(0xFF1A2A3D),
                      iconColor: Color(0xFF5C9BFF),
                    ),
                    _OptionCard(
                      title: 'Networking',
                      subtitle: 'Professional connections',
                      iconData: Icons.hub,
                      iconBg: Color(0xFF1A3D35),
                      iconColor: Color(0xFF5CFFD6),
                    ),
                    _OptionCard(
                      title: 'Hookup',
                      subtitle: 'Something casual',
                      iconData: Icons.local_fire_department,
                      iconBg: Color(0xFF3D1A1A),
                      iconColor: Color(0xFFFF5C5C),
                    ),
                    _OptionCard(
                      title: 'Not sure yet',
                      subtitle: "Let's see",
                      iconData: Icons.help_outline,
                      iconBg: Color(0xFF2A2A3D),
                      iconColor: Colors.white54,
                    ),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
              child: SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF7B2FFF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'Next',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OptionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData iconData;
  final Color iconBg;
  final Color iconColor;

  const _OptionCard({
    required this.title,
    required this.subtitle,
    required this.iconData,
    required this.iconBg,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(14),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iconBg,
              shape: BoxShape.circle,
            ),
            child: Icon(iconData, color: iconColor, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 10,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
