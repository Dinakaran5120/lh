import 'package:flutter/material.dart';

class GroupsHomeScreen extends StatelessWidget {
  const GroupsHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Groups',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1E32),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.add,
                        color: Color(0xFF9B5CFF), size: 20),
                  ),
                ],
              ),
            ),

            // Search bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1E32),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Row(
                  children: [
                    SizedBox(width: 14),
                    Icon(Icons.search, color: Colors.white38, size: 18),
                    SizedBox(width: 8),
                    Text('Search groups...',
                        style: TextStyle(
                            color: Colors.white30, fontSize: 13)),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 14),

            // Category chips
            SizedBox(
              height: 36,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  _CategoryChip(label: 'All', isSelected: true),
                  const SizedBox(width: 8),
                  _CategoryChip(label: 'Travel', isSelected: false),
                  const SizedBox(width: 8),
                  _CategoryChip(label: 'Adventure', isSelected: false),
                  const SizedBox(width: 8),
                  _CategoryChip(label: 'Book Readers', isSelected: false),
                  const SizedBox(width: 8),
                  _CategoryChip(label: 'Gym', isSelected: false),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Explore Groups header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Explore Groups',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: const Text(
                      'See all',
                      style: TextStyle(
                          color: Color(0xFF9B5CFF), fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // Group cards list
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: const [
                  _ExploreGroupCard(
                    name: 'Travel Buddies ✈',
                    tagline: "Let's explore the world together!",
                    memberCount: '1.2K Members',
                    gradientColors: [Color(0xFF1A3040), Color(0xFF0A1828)],
                  ),
                  SizedBox(height: 12),
                  _ExploreGroupCard(
                    name: 'Adventure Seekers 🏔',
                    tagline: 'For thrill lovers and explorers.',
                    memberCount: '856 Members',
                    gradientColors: [Color(0xFF2A1A10), Color(0xFF1A0A08)],
                  ),
                  SizedBox(height: 12),
                  _ExploreGroupCard(
                    name: 'Book Readers 📚',
                    tagline: 'Read more, learn more, grow more.',
                    memberCount: '642 Members',
                    gradientColors: [Color(0xFF1A1A30), Color(0xFF0A0A20)],
                  ),
                  SizedBox(height: 12),
                  _ExploreGroupCard(
                    name: 'Gym Freak 💪',
                    tagline: 'Stronger every day!',
                    memberCount: '1.1K Members',
                    gradientColors: [Color(0xFF1A2A10), Color(0xFF0A1808)],
                  ),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _BottomNavBar(activeIndex: 3),
    );
  }
}

class _ExploreGroupCard extends StatelessWidget {
  final String name;
  final String tagline;
  final String memberCount;
  final List<Color> gradientColors;

  const _ExploreGroupCard({
    required this.name,
    required this.tagline,
    required this.memberCount,
    required this.gradientColors,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 130,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: gradientColors,
        ),
      ),
      clipBehavior: Clip.hardEdge,
      child: Stack(
        children: [
          // Bottom gradient overlay
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xAA000000)],
                ),
              ),
            ),
          ),

          // Content
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  tagline,
                  style: const TextStyle(
                      color: Colors.white70, fontSize: 11),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    // Overlapping member avatars
                    SizedBox(
                      width: 48,
                      height: 22,
                      child: Stack(
                        children: List.generate(3, (i) {
                          return Positioned(
                            left: i * 13.0,
                            child: Container(
                              width: 22,
                              height: 22,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: [
                                  const Color(0xFF9B5CFF),
                                  const Color(0xFFFF6B9D),
                                  const Color(0xFF5C9BFF),
                                ][i],
                                border: Border.all(
                                    color: const Color(0xFF0D0D1E),
                                    width: 1.5),
                              ),
                              child: const Icon(Icons.person,
                                  color: Colors.white, size: 12),
                            ),
                          );
                        }),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      memberCount,
                      style: const TextStyle(
                          color: Colors.white70, fontSize: 11),
                    ),
                    const Spacer(),
                    SizedBox(
                      height: 28,
                      child: ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF7B2FFF),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16),
                          elevation: 0,
                        ),
                        child: const Text(
                          'Join',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  const _CategoryChip({required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFF7B2FFF) : const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(17),
        border: isSelected
            ? null
            : Border.all(color: const Color(0xFF2A2A40)),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white60,
            fontSize: 13,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  final int activeIndex;
  const _BottomNavBar({required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: const BoxDecoration(
        color: Color(0xFF0D0D1E),
        border: Border(top: BorderSide(color: Color(0xFF2A2A40), width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(icon: Icons.explore_outlined, label: 'Discover', isActive: activeIndex == 0),
          _NavItem(icon: Icons.favorite_border, label: 'Matches', isActive: activeIndex == 1),
          _NavItemBadge(icon: Icons.chat_bubble_outline, label: 'Chats', badge: '3', isActive: activeIndex == 2),
          _NavItem(icon: Icons.group, label: 'Groups', isActive: activeIndex == 3),
          _NavItem(icon: Icons.person_outline, label: 'Profile', isActive: activeIndex == 4),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  const _NavItem({required this.icon, required this.label, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, size: 22),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, fontSize: 10)),
      ],
    );
  }
}

class _NavItemBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final String badge;
  final bool isActive;
  const _NavItemBadge({required this.icon, required this.label, required this.badge, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Stack(
          children: [
            Icon(icon, color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, size: 22),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 14,
                height: 14,
                decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                child: Center(child: Text(badge, style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold))),
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, fontSize: 10)),
      ],
    );
  }
}
