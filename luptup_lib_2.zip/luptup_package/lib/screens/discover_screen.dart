import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            // Top App Bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  // Logo
                  Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: const BoxDecoration(
                          color: Color(0xFF7B2FFF),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.favorite,
                          color: Colors.white,
                          size: 14,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text(
                        'lup tup',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  // Coin balance
                  Container(
                    height: 28,
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1E32),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 14,
                          height: 14,
                          decoration: const BoxDecoration(
                            color: Color(0xFFF5A623),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Text(
                          '1,542',
                          style: TextStyle(
                            color: Color(0xFFF5A623),
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 2),
                        const Icon(
                          Icons.add,
                          color: Color(0xFF9B5CFF),
                          size: 14,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Notification bell
                  Stack(
                    children: [
                      const Icon(
                        Icons.notifications_outlined,
                        color: Colors.white,
                        size: 22,
                      ),
                      Positioned(
                        top: 0,
                        right: 0,
                        child: Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Filter chips row
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1E32),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.tune,
                      color: Color(0xFF9B5CFF),
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 8),
                  _FilterChip(label: 'Age 18 - 30', isSelected: true),
                  const SizedBox(width: 8),
                  _FilterChip(label: 'All Orientations', isSelected: false),
                  const SizedBox(width: 8),
                  _FilterChip(
                    label: 'Online',
                    isSelected: false,
                    showOnlineDot: true,
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1E32),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFF2A2A40),
                      ),
                    ),
                    child: const Icon(
                      Icons.sort,
                      color: Colors.white70,
                      size: 16,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 4),

            // Section title
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Discover',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            // Profile list
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: const [
                  _DiscoverCard(
                    name: 'Anaya',
                    age: 24,
                    isOnline: true,
                    interest1: 'Book lover',
                    interest2: 'Cats',
                    location: 'Mumbai, India',
                    isLocked: false,
                    tag: null,
                  ),
                  SizedBox(height: 10),
                  _DiscoverCard(
                    name: 'Riya',
                    age: 25,
                    isOnline: true,
                    interest1: 'Travel',
                    interest2: 'Coffee',
                    location: 'Delhi, India',
                    isLocked: false,
                    tag: null,
                  ),
                  SizedBox(height: 10),
                  _DiscoverCard(
                    name: 'Kabir',
                    age: 26,
                    isOnline: false,
                    interest1: 'Music',
                    interest2: 'Fitness',
                    location: 'Bangalore, India',
                    isLocked: true,
                    tag: 'Popular',
                  ),
                  SizedBox(height: 10),
                  _DiscoverCard(
                    name: 'Meera',
                    age: 23,
                    isOnline: false,
                    interest1: 'Art',
                    interest2: 'Dogs',
                    location: 'Pune, India',
                    isLocked: true,
                    tag: 'Popular',
                  ),
                  SizedBox(height: 10),
                  _DiscoverCard(
                    name: 'Arjun',
                    age: 25,
                    isOnline: false,
                    interest1: 'Movies',
                    interest2: 'Road Trips',
                    location: 'Hyderabad, India',
                    isLocked: true,
                    tag: 'New',
                  ),
                  SizedBox(height: 10),
                  _DiscoverCard(
                    name: 'Simran',
                    age: 24,
                    isOnline: false,
                    interest1: 'Cooking',
                    interest2: 'Photography',
                    location: 'Chandigarh, India',
                    isLocked: true,
                    tag: 'New',
                  ),
                  SizedBox(height: 80),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _BottomNavBar(activeIndex: 0),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final bool showOnlineDot;

  const _FilterChip({
    required this.label,
    required this.isSelected,
    this.showOnlineDot = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: isSelected
            ? const Color(0xFF2A1A4A)
            : const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isSelected
              ? const Color(0xFF9B5CFF)
              : const Color(0xFF2A2A40),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (showOnlineDot) ...[
            Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: Color(0xFF2ECC71),
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: TextStyle(
              color: isSelected ? const Color(0xFF9B5CFF) : Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 4),
          Icon(
            Icons.keyboard_arrow_down,
            color: isSelected ? const Color(0xFF9B5CFF) : Colors.white38,
            size: 14,
          ),
        ],
      ),
    );
  }
}

class _DiscoverCard extends StatelessWidget {
  final String name;
  final int age;
  final bool isOnline;
  final String interest1;
  final String interest2;
  final String location;
  final bool isLocked;
  final String? tag;

  const _DiscoverCard({
    required this.name,
    required this.age,
    required this.isOnline,
    required this.interest1,
    required this.interest2,
    required this.location,
    required this.isLocked,
    required this.tag,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 82,
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Stack(
        children: [
          Row(
            children: [
              // Avatar
              ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(14),
                  bottomLeft: Radius.circular(14),
                ),
                child: Container(
                  width: 82,
                  height: 82,
                  color: const Color(0xFF2A2A40),
                  child: isLocked
                      ? Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(color: const Color(0xFF1E1E2E)),
                            const Icon(
                              Icons.lock,
                              color: Colors.white38,
                              size: 22,
                            ),
                          ],
                        )
                      : const Icon(
                          Icons.person,
                          color: Colors.white38,
                          size: 32,
                        ),
                ),
              ),
              const SizedBox(width: 12),

              // Info
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text(
                            '$name, $age',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(width: 4),
                          const Icon(
                            Icons.verified,
                            color: Color(0xFF9B5CFF),
                            size: 14,
                          ),
                        ],
                      ),
                      if (isOnline)
                        Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                color: Color(0xFF2ECC71),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Text(
                              'Online',
                              style: TextStyle(
                                color: Colors.white54,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      Row(
                        children: [
                          const Icon(
                            Icons.auto_stories,
                            color: Colors.white54,
                            size: 12,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            interest1,
                            style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 11,
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(
                            Icons.pets,
                            color: Colors.white54,
                            size: 12,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            interest2,
                            style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          const Icon(
                            Icons.location_on,
                            color: Colors.white38,
                            size: 12,
                          ),
                          const SizedBox(width: 2),
                          Text(
                            location,
                            style: const TextStyle(
                              color: Colors.white38,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              // Right action
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: isLocked
                    ? Container(
                        width: 52,
                        height: 44,
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A1A3D),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 14,
                              height: 14,
                              decoration: const BoxDecoration(
                                color: Color(0xFFF5A623),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(height: 3),
                            const Text(
                              '50',
                              style: TextStyle(
                                color: Color(0xFFF5A623),
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const Text(
                              'Unlock',
                              style: TextStyle(
                                color: Colors.white54,
                                fontSize: 8,
                              ),
                            ),
                          ],
                        ),
                      )
                    : GestureDetector(
                        onTap: () => context.push(AppRoutes.userProfileDetail),
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: const BoxDecoration(
                            color: Color(0xFF2A1A4A),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.favorite_border,
                            color: Color(0xFF9B5CFF),
                            size: 18,
                          ),
                        ),
                      ),
              ),
            ],
          ),

          // Tag pill (Popular / New)
          if (tag != null)
            Positioned(
              top: 8,
              left: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: tag == 'Popular'
                      ? const Color(0xFF7B2FFF)
                      : const Color(0xFF1A3D1A),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  tag!,
                  style: TextStyle(
                    color: tag == 'Popular'
                        ? Colors.white
                        : const Color(0xFF2ECC71),
                    fontSize: 8,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  final int activeIndex;

  const _BottomNavBar({required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: const BoxDecoration(
        color: Color(0xFF0D0D1E),
        border: Border(top: BorderSide(color: Color(0xFF2A2A40), width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(icon: Icons.explore, label: 'Discover', isActive: activeIndex == 0),
          _NavItem(icon: Icons.mood, label: 'Mood', isActive: activeIndex == 1),
          _NavItem(icon: Icons.favorite_border, label: 'Matches', isActive: activeIndex == 2),
          _NavItemWithBadge(icon: Icons.chat_bubble_outline, label: 'Chats', badge: '3', isActive: activeIndex == 3),
          _NavItem(icon: Icons.person_outline, label: 'Profile', isActive: activeIndex == 4),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          icon,
          color: isActive ? const Color(0xFF9B5CFF) : Colors.white38,
          size: 22,
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: isActive ? const Color(0xFF9B5CFF) : Colors.white38,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}

class _NavItemWithBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final String badge;
  final bool isActive;

  const _NavItemWithBadge({
    required this.icon,
    required this.label,
    required this.badge,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Stack(
          children: [
            Icon(
              icon,
              color: isActive ? const Color(0xFF9B5CFF) : Colors.white38,
              size: 22,
            ),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 14,
                height: 14,
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    badge,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: isActive ? const Color(0xFF9B5CFF) : Colors.white38,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}
