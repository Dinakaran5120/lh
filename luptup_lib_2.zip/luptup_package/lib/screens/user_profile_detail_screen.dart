import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class UserProfileDetailScreen extends StatelessWidget {
  const UserProfileDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: Column(
        children: [
          // Hero image with overlaid top bar
          SizedBox(
            height: 260,
            child: Stack(
              children: [
                // Hero photo background
                Positioned.fill(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFF2A1040),
                          Color(0xFF6B3A1A),
                        ],
                      ),
                    ),
                    child: const Icon(
                      Icons.person,
                      color: Colors.white24,
                      size: 80,
                    ),
                  ),
                ),
                // Bottom fade
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: 80,
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Color(0xFF0D0D1E)],
                      ),
                    ),
                  ),
                ),
                // Top bar
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () => context.pop(),
                          child: Container(
                            width: 36,
                            height: 36,
                            decoration: const BoxDecoration(
                              color: Colors.black26,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.arrow_back_ios,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () => context.push(AppRoutes.settings),
                          child: Container(
                            width: 36,
                            height: 36,
                            decoration: const BoxDecoration(
                              color: Colors.black26,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.settings_outlined,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Avatar circle (overlapping bottom of hero)
                Positioned(
                  bottom: 12,
                  left: 20,
                  child: Stack(
                    children: [
                      Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: const Color(0xFF0D0D1E),
                            width: 3,
                          ),
                          color: const Color(0xFF2A2A40),
                        ),
                        child: const ClipOval(
                          child: Icon(
                            Icons.person,
                            color: Colors.white38,
                            size: 40,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            color: const Color(0xFF7B2FFF),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFF0D0D1E),
                              width: 2,
                            ),
                          ),
                          child: const Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Profile info
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Name + verified
                  Row(
                    children: [
                      const Text(
                        'Anaya, 24',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Icon(
                        Icons.verified,
                        color: Color(0xFF9B5CFF),
                        size: 18,
                      ),
                    ],
                  ),

                  const SizedBox(height: 4),

                  // Pronouns + orientation
                  const Text(
                    'She/Her | Bisexual',
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 13,
                    ),
                  ),

                  const SizedBox(height: 6),

                  // Online + location + distance
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Color(0xFF2ECC71),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                      const Text(
                        'Online  •  Delhi, India  •  ',
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 12,
                        ),
                      ),
                      const Text(
                        '3 km away',
                        style: TextStyle(
                          color: Color(0xFF9B5CFF),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),

                  // Interest chips row
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: const [
                      _InterestChip(label: 'Travel'),
                      _InterestChip(label: 'Coffee'),
                      _InterestChip(label: 'Music'),
                      _InterestChip(label: 'Photography'),
                      _InterestChip(label: 'Dogs'),
                    ],
                  ),

                  const SizedBox(height: 18),

                  // About me
                  const Text(
                    'About me',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'I love deep talks, spontaneous trips, and kind people. Let\'s create some memories ✨',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 13,
                      height: 1.6,
                    ),
                  ),

                  const SizedBox(height: 18),

                  // Interests
                  const Text(
                    'Interests',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: const [
                      _InterestChip(label: 'Travel'),
                      _InterestChip(label: 'Photography'),
                      _InterestChip(label: 'Music'),
                      _InterestChip(label: 'Books'),
                      _InterestChip(label: 'Dogs'),
                      _InterestChip(label: 'Coffee'),
                    ],
                  ),

                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _BottomNavBar(activeIndex: 4),
    );
  }
}

class _InterestChip extends StatelessWidget {
  final String label;

  const _InterestChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Center(
        child: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  final int activeIndex;

  const _BottomNavBar({required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: const BoxDecoration(
        color: Color(0xFF0D0D1E),
        border: Border(top: BorderSide(color: Color(0xFF2A2A40), width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(icon: Icons.explore, label: 'Discover', isActive: activeIndex == 0),
          _NavItem(icon: Icons.mood, label: 'Mood', isActive: activeIndex == 1),
          _NavItem(icon: Icons.favorite_border, label: 'Matches', isActive: activeIndex == 2),
          _NavItemWithBadge(icon: Icons.chat_bubble_outline, label: 'Chats', badge: '2', isActive: activeIndex == 3),
          _NavItem(icon: Icons.person_outline, label: 'Profile', isActive: activeIndex == 4),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, size: 22),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: isActive ? const Color(0xFF9B5CFF) : Colors.white38,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}

class _NavItemWithBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final String badge;
  final bool isActive;

  const _NavItemWithBadge({
    required this.icon,
    required this.label,
    required this.badge,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Stack(
          children: [
            Icon(icon, color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, size: 22),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 14,
                height: 14,
                decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                child: Center(
                  child: Text(badge, style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: isActive ? const Color(0xFF9B5CFF) : Colors.white38,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}
