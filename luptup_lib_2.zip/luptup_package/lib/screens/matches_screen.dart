import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class MatchesScreen extends StatelessWidget {
  const MatchesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Matches',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Icon(
                    Icons.favorite,
                    color: Color(0xFF9B5CFF),
                    size: 22,
                  ),
                ],
              ),
            ),

            // Search bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Container(
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1E32),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Row(
                  children: [
                    SizedBox(width: 14),
                    Icon(Icons.search, color: Colors.white38, size: 18),
                    SizedBox(width: 8),
                    Text(
                      'Search matches',
                      style: TextStyle(
                        color: Colors.white30,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 12),

            // Top matches horizontal scroll
            SizedBox(
              height: 90,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: const [
                  _TopMatchAvatar(name: 'Anaya', isOnline: true),
                  SizedBox(width: 12),
                  _TopMatchAvatar(name: 'Meera', isOnline: true),
                  SizedBox(width: 12),
                  _TopMatchAvatar(name: 'Riya', isOnline: false),
                  SizedBox(width: 12),
                  _TopMatchAvatar(name: 'Kabir', isOnline: true),
                  SizedBox(width: 12),
                  _TopMatchAvatarPlus(count: '+2'),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // Messages section header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const Text(
                    'Messages',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  const Text(
                    'Unread',
                    style: TextStyle(
                      color: Color(0xFF9B5CFF),
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    height: 18,
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF9B5CFF),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Center(
                      child: Text(
                        '4',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Messages list
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: const [
                  _MessageTile(
                    name: 'Anaya',
                    lastMessage: 'Hey! Loved your travel shot ✈️',
                    time: '9:41 AM',
                    unreadCount: 2,
                    isOnline: true,
                  ),
                  _MessageTile(
                    name: 'Meera',
                    lastMessage: 'That playlist was 🔥',
                    time: '9:30 AM',
                    unreadCount: 1,
                    isOnline: true,
                  ),
                  _MessageTile(
                    name: 'Riya',
                    lastMessage: 'Down for a coffee sometime?',
                    time: 'Yesterday',
                    unreadCount: 0,
                    isOnline: false,
                  ),
                  _MessageTile(
                    name: 'Arjun',
                    lastMessage: 'Nice to connect! 🌟',
                    time: 'Mon',
                    unreadCount: 0,
                    isOnline: false,
                  ),
                  _MessageTile(
                    name: 'Kabir',
                    lastMessage: "Let's collaborate sometime.",
                    time: 'Mon',
                    unreadCount: 0,
                    isOnline: false,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _BottomNavBar(activeIndex: 2),
    );
  }
}

class _TopMatchAvatar extends StatelessWidget {
  final String name;
  final bool isOnline;
  const _TopMatchAvatar({required this.name, required this.isOnline});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF2A2A40),
                border: Border.all(color: const Color(0xFF7B2FFF), width: 2),
              ),
              child: const ClipOval(
                child: Icon(Icons.person, color: Colors.white38, size: 30),
              ),
            ),
            if (isOnline)
              Positioned(
                bottom: 2,
                right: 2,
                child: Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: const Color(0xFF2ECC71),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: const Color(0xFF0D0D1E), width: 2),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 5),
        Text(
          name,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
          ),
        ),
      ],
    );
  }
}

class _TopMatchAvatarPlus extends StatelessWidget {
  final String count;
  const _TopMatchAvatarPlus({required this.count});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFF2A1A4A),
            border: Border.all(color: const Color(0xFF7B2FFF), width: 2),
          ),
          child: Center(
            child: Text(
              count,
              style: const TextStyle(
                color: Color(0xFF9B5CFF),
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        const SizedBox(height: 5),
        const Text(
          'More',
          style: TextStyle(color: Colors.white54, fontSize: 11),
        ),
      ],
    );
  }
}

class _MessageTile extends StatelessWidget {
  final String name;
  final String lastMessage;
  final String time;
  final int unreadCount;
  final bool isOnline;

  const _MessageTile({
    required this.name,
    required this.lastMessage,
    required this.time,
    required this.unreadCount,
    required this.isOnline,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push(AppRoutes.chatDetail),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: SizedBox(
          height: 72,
          child: Row(
          children: [
            Stack(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF2A2A40),
                  ),
                  child: const ClipOval(
                    child: Icon(Icons.person, color: Colors.white38, size: 26),
                  ),
                ),
                if (isOnline)
                  Positioned(
                    bottom: 2,
                    right: 2,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: const Color(0xFF2ECC71),
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: const Color(0xFF0D0D1E), width: 2),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    lastMessage,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 12,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  time,
                  style: const TextStyle(
                    color: Colors.white38,
                    fontSize: 11,
                  ),
                ),
                const SizedBox(height: 4),
                if (unreadCount > 0)
                  Container(
                    width: 20,
                    height: 20,
                    decoration: const BoxDecoration(
                      color: Color(0xFF9B5CFF),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text(
                        unreadCount.toString(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    ));
  }
}

class _BottomNavBar extends StatelessWidget {
  final int activeIndex;
  const _BottomNavBar({required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: const BoxDecoration(
        color: Color(0xFF0D0D1E),
        border: Border(top: BorderSide(color: Color(0xFF2A2A40), width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(icon: Icons.explore_outlined, label: 'Discover', isActive: activeIndex == 0),
          _NavItem(icon: Icons.mood, label: 'Mood', isActive: activeIndex == 1),
          _NavItem(icon: Icons.favorite, label: 'Matches', isActive: activeIndex == 2),
          _NavItemBadge(icon: Icons.chat_bubble_outline, label: 'Chats', badge: '3', isActive: activeIndex == 3),
          _NavItem(icon: Icons.person_outline, label: 'Profile', isActive: activeIndex == 4),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  const _NavItem({required this.icon, required this.label, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, size: 22),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, fontSize: 10)),
      ],
    );
  }
}

class _NavItemBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final String badge;
  final bool isActive;
  const _NavItemBadge({required this.icon, required this.label, required this.badge, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Stack(
          children: [
            Icon(icon, color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, size: 22),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 14,
                height: 14,
                decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                child: Center(child: Text(badge, style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold))),
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: isActive ? const Color(0xFF9B5CFF) : Colors.white38, fontSize: 10)),
      ],
    );
  }
}
