FONTS FOLDER — LUP TUP APP
===========================

The app uses: fontFamily: 'SF Pro Display'

OPTIONS:
--------

OPTION A — Use SF Pro Display (Apple devices only)
  SF Pro is built into iOS/macOS. No file needed on Apple devices.
  On Android it falls back to the system default font (Roboto).
  This is fine for development.

OPTION B — Use Inter (recommended for cross-platform)
  1. Download from: https://fonts.google.com/specimen/Inter
  2. Place files here:
       assets/fonts/Inter-Regular.ttf
       assets/fonts/Inter-Medium.ttf
       assets/fonts/Inter-SemiBold.ttf
       assets/fonts/Inter-Bold.ttf
  3. Update pubspec.yaml:
       flutter:
         fonts:
           - family: SF Pro Display
             fonts:
               - asset: assets/fonts/Inter-Regular.ttf
               - asset: assets/fonts/Inter-Medium.ttf
                 weight: 500
               - asset: assets/fonts/Inter-SemiBold.ttf
                 weight: 600
               - asset: assets/fonts/Inter-Bold.ttf
                 weight: 700

OPTION C — Use system default (quickest)
  In app_theme.dart, remove the fontFamily lines entirely.
  Flutter will use Roboto on Android and SF Pro on iOS automatically.

