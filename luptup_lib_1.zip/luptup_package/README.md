# Lup Tup — Asset Guide

## assets/images/

### REQUIRED (app crashes without these)
| File | Used In | Size | Replace With |
|------|---------|------|--------------|
| couple_sunset_bg.png | SplashLoginScreen background | 1080×1920 | Real romantic sunset photo |
| couple_embrace_bg.png | OnboardingSlideScreen background | 1080×1920 | Real couple embrace photo |
| luptup_logo_icon.png | Splash logo, Settings profile card | 200×200 | Real Lup Tup heart logo PNG |

### RECOMMENDED (screens use Icon() fallbacks without these)
| File | Used In | Size | Replace With |
|------|---------|------|--------------|
| profile_anaya.png | Discover, Matches, Chat | 400×500 | Real profile photo |
| profile_riya.png | Discover, Matches | 400×500 | Real profile photo |
| profile_kabir.png | Discover, Matches, Groups | 400×500 | Real profile photo |
| profile_meera.png | Discover, Matches | 400×500 | Real profile photo |
| profile_arjun.png | Discover, Groups | 400×500 | Real profile photo |
| group_travel.png | GroupsHome card background | 400×300 | Mountain/travel landscape |
| group_adventure.png | GroupsHome card background | 400×300 | Adventure landscape |
| group_books.png | GroupsHome card background | 400×300 | Books/library photo |
| group_gym.png | GroupsHome card background | 400×300 | Gym/fitness photo |
| introvert_illustration.png | IntrovertModeScreen hero | 400×400 | Custom illustration |
| premium_crown.png | LupTupPremiumScreen hero | 300×300 | Crown/premium illustration |

## assets/icons/

### REQUIRED
| File | Used In | Size | Replace With |
|------|---------|------|--------------|
| google_logo.png | SplashLoginScreen Google button | 200×200 | Official Google G logo |
| apple_logo.png | SplashLoginScreen Apple button | 200×200 | Official Apple logo |

### RECOMMENDED
| File | Used In | Size | Replace With |
|------|---------|------|--------------|
| coin.png | Discover, Premium, Mood feed | 100×100 | Gold coin illustration |
| coin_pile.png | Premium screen packages | 200×150 | Coin stack illustration |
| crown.png | MyGroups Premium card | 100×100 | Crown icon |
| lock.png | Discover locked profiles | 100×100 | Lock icon |

## assets/fonts/
See fonts/README.txt for font setup instructions.
Placeholder files are included — replace with real .ttf files.

## Where to get real assets
- Photos: https://unsplash.com (free, high quality)
- Icons: https://www.flaticon.com or https://icons8.com
- Illustrations: https://undraw.co (free, customizable color)
- Google Logo: https://developers.google.com/identity/branding-guidelines
- Apple Logo: https://developer.apple.com/design/human-interface-guidelines/sign-in-with-apple
- Fonts: https://fonts.google.com/specimen/Inter
