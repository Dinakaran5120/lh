import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class LupTupPremiumScreen extends StatelessWidget {
  const LupTupPremiumScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 16),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(Icons.arrow_back_ios,
                        color: Color(0xFF9B5CFF), size: 20),
                  ),
                  const Expanded(
                    child: Text(
                      'Lup Tup Premium',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                ],
              ),
            ),

            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Hero banner
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Container(
                        height: 160,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFF3A0080),
                              Color(0xFF1A004A),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              right: 16,
                              top: 16,
                              child: Container(
                                width: 80,
                                height: 80,
                                decoration: const BoxDecoration(
                                  color: Color(0x33F5A623),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                    Icons.workspace_premium,
                                    color: Color(0xFFF5A623),
                                    size: 40),
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.all(20),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.end,
                                children: [
                                  Text('Go Premium,',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 22,
                                          fontWeight:
                                              FontWeight.w700)),
                                  Text('Get Noticed 💜',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 22,
                                          fontWeight:
                                              FontWeight.w700)),
                                  SizedBox(height: 4),
                                  Text(
                                      'Unlock exclusive features and\nstand out from the crowd.',
                                      style: TextStyle(
                                          color: Colors.white70,
                                          fontSize: 12,
                                          height: 1.4)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Features icon row
                    SizedBox(
                      height: 80,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16),
                        children: const [
                          _PremiumFeatureIcon(
                              icon: Icons.favorite_border,
                              label: 'See Who\nLikes You'),
                          SizedBox(width: 16),
                          _PremiumFeatureIcon(
                              icon: Icons.all_inclusive,
                              label: 'Unlimited\nLikes'),
                          SizedBox(width: 16),
                          _PremiumFeatureIcon(
                              icon: Icons.send,
                              label: 'Priority\nMatches'),
                          SizedBox(width: 16),
                          _PremiumFeatureIcon(
                              icon: Icons.visibility,
                              label: 'Profile\nBoost'),
                          SizedBox(width: 16),
                          _PremiumFeatureIcon(
                              icon: Icons.verified,
                              label: 'Verified\nBadge'),
                          SizedBox(width: 16),
                          _PremiumFeatureIcon(
                              icon: Icons.visibility_off,
                              label: 'Incognito\nBadge'),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    // My Coins row
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16),
                      child: Row(
                        children: [
                          Container(
                            width: 32,
                            height: 32,
                            decoration: const BoxDecoration(
                              color: Color(0xFFF5A623),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.monetization_on,
                                color: Colors.white, size: 18),
                          ),
                          const SizedBox(width: 8),
                          const Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text('125',
                                  style: TextStyle(
                                      color: Color(0xFFF5A623),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700)),
                              Text('My Coins',
                                  style: TextStyle(
                                      color: Colors.white54,
                                      fontSize: 11)),
                            ],
                          ),
                          const Spacer(),
                          GestureDetector(
                            onTap: () {},
                            child: const Text(
                              'Transaction History >',
                              style: TextStyle(
                                  color: Color(0xFF9B5CFF),
                                  fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Buy Coins section
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Buy Coins',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600)),
                          SizedBox(height: 4),
                          Text(
                              'Use coins to send gifts, boost profile and more.',
                              style: TextStyle(
                                  color: Colors.white54,
                                  fontSize: 12)),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Coin packages grid
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16),
                      child: GridView.count(
                        crossAxisCount: 3,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        childAspectRatio: 1.0,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        children: const [
                          _CoinPackage(
                              coins: '100',
                              price: '₹89.00',
                              isBestValue: false,
                              discountLabel: null),
                          _CoinPackage(
                              coins: '250',
                              price: '₹199.00',
                              isBestValue: false,
                              discountLabel: null),
                          _CoinPackage(
                              coins: '550',
                              price: '₹399.00',
                              isBestValue: false,
                              discountLabel: '30%'),
                          _CoinPackage(
                              coins: '1200',
                              price: '₹799.00',
                              isBestValue: false,
                              discountLabel: null),
                          _CoinPackage(
                              coins: '2500',
                              price: '₹1,499.00',
                              isBestValue: true,
                              discountLabel: null),
                          _CoinPackage(
                              coins: '5000',
                              price: '₹2,499.00',
                              isBestValue: false,
                              discountLabel: '30%'),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Premium Membership row
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16),
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E1E32),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 14),
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration: const BoxDecoration(
                                color: Color(0xFF2A1A4A),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                  Icons.workspace_premium,
                                  color: Color(0xFFF5A623),
                                  size: 18),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      const Text(
                                        'Premium Membership',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 13,
                                            fontWeight:
                                                FontWeight.w600),
                                      ),
                                      const SizedBox(width: 6),
                                      Container(
                                        padding:
                                            const EdgeInsets.symmetric(
                                                horizontal: 6,
                                                vertical: 2),
                                        decoration: BoxDecoration(
                                          color:
                                              const Color(0xFF7B2FFF),
                                          borderRadius:
                                              BorderRadius.circular(
                                                  6),
                                        ),
                                        child: const Text(
                                          'Most Popular',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 9),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 3),
                                  const Text(
                                    'Unlimited coins + all premium features',
                                    style: TextStyle(
                                        color: Colors.white54,
                                        fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            SizedBox(
                              height: 34,
                              child: ElevatedButton(
                                onPressed: () {},
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      const Color(0xFF7B2FFF),
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(17),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12),
                                  elevation: 0,
                                ),
                                child: const Row(
                                  children: [
                                    Text('View Plans',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 12)),
                                    SizedBox(width: 2),
                                    Icon(Icons.chevron_right,
                                        color: Colors.white, size: 14),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Footer
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                      child: Row(
                        mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                        children: [
                          const Row(
                            children: [
                              Icon(Icons.help_outline,
                                  color: Colors.white54, size: 14),
                              SizedBox(width: 4),
                              Text('Need help with payment?',
                                  style: TextStyle(
                                      color: Colors.white54,
                                      fontSize: 11)),
                            ],
                          ),
                          GestureDetector(
                            onTap: () {},
                            child: const Text(
                              'Contact Support >',
                              style: TextStyle(
                                  color: Color(0xFF9B5CFF),
                                  fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PremiumFeatureIcon extends StatelessWidget {
  final IconData icon;
  final String label;

  const _PremiumFeatureIcon(
      {required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: const BoxDecoration(
            color: Color(0xFF1E1E32),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: const Color(0xFF9B5CFF), size: 20),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          textAlign: TextAlign.center,
          style:
              const TextStyle(color: Colors.white60, fontSize: 10),
        ),
      ],
    );
  }
}

class _CoinPackage extends StatelessWidget {
  final String coins;
  final String price;
  final bool isBestValue;
  final String? discountLabel;

  const _CoinPackage({
    required this.coins,
    required this.price,
    required this.isBestValue,
    required this.discountLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          decoration: BoxDecoration(
            color: isBestValue
                ? const Color(0xFF2A1A4A)
                : const Color(0xFF1E1E32),
            borderRadius: BorderRadius.circular(12),
            border: isBestValue
                ? Border.all(
                    color: const Color(0xFF9B5CFF), width: 1.5)
                : null,
          ),
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: const BoxDecoration(
                  color: Color(0xFFF5A623),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.monetization_on,
                    color: Colors.white, size: 20),
              ),
              const SizedBox(height: 6),
              Text(
                coins,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700),
              ),
              const Text('Coins',
                  style: TextStyle(
                      color: Colors.white54, fontSize: 9)),
              const SizedBox(height: 4),
              Text(
                price,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        if (isBestValue)
          Positioned(
            top: -8,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5A623),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'BEST VALUE',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 8,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        if (discountLabel != null)
          Positioned(
            top: 6,
            right: 6,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 5, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                '$discountLabel off',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 7,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
      ],
    );
  }
}
