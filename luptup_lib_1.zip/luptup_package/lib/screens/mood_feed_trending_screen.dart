import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class MoodFeedTrendingScreen extends StatelessWidget {
  const MoodFeedTrendingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            _TopAppBar(),
            _FeedTabBar(activeTab: 2),
            _SubFilterRow(),
            _HotBanner(),
            _TrendingCreatorsSection(),
            _TrendingPostsHeader(),
            Expanded(child: _TrendingPostsList()),
          ],
        ),
      ),
      bottomNavigationBar: _BottomNavBar(activeIndex: 0),
    );
  }
}

// ── Top App Bar ───────────────────────────────────────────────────────────────
class _TopAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Row(children: [
            Container(
              width: 26,
              height: 26,
              decoration: const BoxDecoration(
                  color: Color(0xFF7B2FFF), shape: BoxShape.circle),
              child:
                  const Icon(Icons.favorite, color: Colors.white, size: 13),
            ),
            const SizedBox(width: 6),
            const Text('lup tup',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold)),
          ]),
          const Spacer(),
          Container(
            height: 28,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
                color: const Color(0xFF1E1E32),
                borderRadius: BorderRadius.circular(14)),
            child: Row(children: [
              Container(
                  width: 14,
                  height: 14,
                  decoration: const BoxDecoration(
                      color: Color(0xFFF5A623), shape: BoxShape.circle)),
              const SizedBox(width: 4),
              const Text('1,542',
                  style: TextStyle(
                      color: Color(0xFFF5A623),
                      fontSize: 13,
                      fontWeight: FontWeight.w600)),
              const SizedBox(width: 2),
              const Icon(Icons.add, color: Color(0xFF9B5CFF), size: 14),
            ]),
          ),
          const SizedBox(width: 8),
          Stack(children: [
            const Icon(Icons.notifications_outlined,
                color: Colors.white, size: 22),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                      color: Colors.red, shape: BoxShape.circle)),
            ),
          ]),
        ],
      ),
    );
  }
}

// ── Feed Tab Bar ──────────────────────────────────────────────────────────────
class _FeedTabBar extends StatelessWidget {
  final int activeTab;
  const _FeedTabBar({required this.activeTab});

  @override
  Widget build(BuildContext context) {
    final tabs = ['For You', 'Following', 'Trending'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: List.generate(tabs.length, (i) {
          final isActive = i == activeTab;
          return Padding(
            padding: EdgeInsets.only(right: i < tabs.length - 1 ? 20 : 0),
            child: Column(
              children: [
                Text(
                  tabs[i],
                  style: TextStyle(
                    color: isActive ? Colors.white : Colors.white54,
                    fontSize: 14,
                    fontWeight: isActive
                        ? FontWeight.w600
                        : FontWeight.w400,
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  height: 2,
                  width: isActive ? 60 : 0,
                  color: const Color(0xFF9B5CFF),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// ── Sub Filter Row ────────────────────────────────────────────────────────────
class _SubFilterRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        children: [
          _FilterPill(label: 'All', isSelected: true),
          const SizedBox(width: 8),
          _FilterPill(label: '🔥 Popular Now', isSelected: false),
          const SizedBox(width: 8),
          _FilterPill(label: '⭐ Rising Stars', isSelected: false),
          const SizedBox(width: 8),
          _FilterPill(label: '🏆 Top Creators', isSelected: false),
          const SizedBox(width: 8),
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
                color: const Color(0xFF1E1E32),
                borderRadius: BorderRadius.circular(8)),
            child: const Icon(Icons.tune,
                color: Color(0xFF9B5CFF), size: 16),
          ),
        ],
      ),
    );
  }
}

// ── Hot Banner ────────────────────────────────────────────────────────────────
class _HotBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Container(
        decoration: BoxDecoration(
            color: const Color(0xFF1E1E32),
            borderRadius: BorderRadius.circular(12)),
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            const Icon(Icons.local_fire_department,
                color: Color(0xFFFF6B35), size: 18),
            const SizedBox(width: 6),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("What's hot right now",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600)),
                  Text('The most loved posts and creators on Lup Tup',
                      style: TextStyle(
                          color: Colors.white54, fontSize: 11)),
                ],
              ),
            ),
            SizedBox(
              height: 28,
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7B2FFF),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  elevation: 0,
                ),
                child: const Text('View Weekly Rank',
                    style:
                        TextStyle(color: Colors.white, fontSize: 11)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Trending Creators Section ─────────────────────────────────────────────────
class _TrendingCreatorsSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    const creators = [
      _CreatorData('Kabir', '86.4K', 1),
      _CreatorData('Anaya', '75.2K', 2),
      _CreatorData('Riya', '62.1K', 3),
      _CreatorData('Arjun', '51.3K', 4),
      _CreatorData('Meera', '48.7K', 5),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Trending Creators',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600)),
              GestureDetector(
                onTap: () {},
                child: const Text('View all',
                    style: TextStyle(
                        color: Color(0xFF9B5CFF), fontSize: 13)),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 84,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: creators.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (_, i) =>
                _TrendingCreatorAvatar(data: creators[i]),
          ),
        ),
      ],
    );
  }
}

class _CreatorData {
  final String name;
  final String followers;
  final int rank;
  const _CreatorData(this.name, this.followers, this.rank);
}

class _TrendingCreatorAvatar extends StatelessWidget {
  final _CreatorData data;
  const _TrendingCreatorAvatar({required this.data});

  Color get rankColor {
    switch (data.rank) {
      case 1:
        return const Color(0xFFFFD700);
      case 2:
        return const Color(0xFFC0C0C0);
      case 3:
        return const Color(0xFFCD7F32);
      default:
        return const Color(0xFF9B5CFF);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: rankColor, width: 2),
                color: const Color(0xFF2A2A40),
              ),
              child: const ClipOval(
                child: Icon(Icons.person,
                    color: Colors.white38, size: 26),
              ),
            ),
            Positioned(
              top: -4,
              left: -4,
              child: Container(
                width: 18,
                height: 18,
                decoration: BoxDecoration(
                    color: rankColor, shape: BoxShape.circle),
                child: Center(
                  child: Text('${data.rank}',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.w700)),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text('${data.name} ✓',
            style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w500)),
        Text('${data.followers} followers',
            style: const TextStyle(
                color: Colors.white54, fontSize: 9)),
      ],
    );
  }
}

// ── Trending Posts Header ─────────────────────────────────────────────────────
class _TrendingPostsHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          const Text('Trending Posts',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w600)),
          const SizedBox(width: 10),
          Row(children: [
            _PostTabChip(label: 'All', isActive: true),
            const SizedBox(width: 6),
            _PostTabChip(label: 'Videos', isActive: false),
            const SizedBox(width: 6),
            _PostTabChip(label: 'Photos', isActive: false),
            const SizedBox(width: 6),
            _PostTabChip(label: 'Text', isActive: false),
          ]),
          const Spacer(),
          const Text('View all',
              style: TextStyle(
                  color: Color(0xFF9B5CFF), fontSize: 13)),
        ],
      ),
    );
  }
}

class _PostTabChip extends StatelessWidget {
  final String label;
  final bool isActive;
  const _PostTabChip({required this.label, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: isActive
            ? const Color(0xFF7B2FFF)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(label,
          style: TextStyle(
              color:
                  isActive ? Colors.white : Colors.white54,
              fontSize: 11)),
    );
  }
}

// ── Trending Posts List ───────────────────────────────────────────────────────
class _TrendingPostsList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    const posts = [
      _PostData('Anaya', 'Chasing sunsets and dreams ✨💜', '0:19',
          '1,256', '86', '52', '230'),
      _PostData('Riya',
          'Golden hour in paradise 🌅 Bali never disappoints!',
          '0:15', '942', '64', '38', '180'),
      _PostData('Kabir', 'A little reminder for your Monday 💪',
          '', '713', '35', '21', '90'),
      _PostData('Arjun',
          'Road trips, good vibes and endless conversations 🚗✨',
          '0:20', '665', '51', '27', '140'),
    ];
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: posts.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) => _TrendingPostCard(post: posts[i]),
    );
  }
}

class _PostData {
  final String creator;
  final String caption;
  final String duration;
  final String likes;
  final String comments;
  final String superLikes;
  final String coins;
  const _PostData(this.creator, this.caption, this.duration,
      this.likes, this.comments, this.superLikes, this.coins);
}

class _TrendingPostCard extends StatelessWidget {
  final _PostData post;
  const _TrendingPostCard({required this.post});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 76,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          // Thumbnail
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Stack(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF2A1040), Color(0xFF1A2040)],
                    ),
                  ),
                  child: post.duration.isEmpty
                      ? const Center(
                          child: Icon(Icons.text_snippet_outlined,
                              color: Colors.white38, size: 26))
                      : const Center(
                          child: Icon(Icons.play_circle_fill,
                              color: Colors.white38, size: 28)),
                ),
                if (post.duration.isNotEmpty)
                  Positioned(
                    bottom: 4,
                    left: 4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 4, vertical: 2),
                      decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(4)),
                      child: Text(post.duration,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 8)),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 10),

          // Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(children: [
                  Container(
                    width: 16,
                    height: 16,
                    decoration: const BoxDecoration(
                        color: Color(0xFF2A2A40),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.person,
                        color: Colors.white38, size: 10),
                  ),
                  const SizedBox(width: 4),
                  Text('${post.creator} ✓',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600)),
                ]),
                const SizedBox(height: 3),
                Text(post.caption,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 11)),
                const SizedBox(height: 4),
                Row(children: [
                  _MiniStat(icon: Icons.favorite, value: post.likes),
                  const SizedBox(width: 10),
                  _MiniStat(
                      icon: Icons.chat_bubble_outline,
                      value: post.comments),
                  const SizedBox(width: 10),
                  _MiniStat(
                      icon: Icons.star_border,
                      value: post.superLikes),
                  const SizedBox(width: 10),
                  _MiniStat(
                      icon: Icons.monetization_on_outlined,
                      value: post.coins),
                ]),
              ],
            ),
          ),
          const SizedBox(width: 6),

          // Unlock badge
          Container(
            height: 26,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
                color: const Color(0xFF2A1A3D),
                borderRadius: BorderRadius.circular(13)),
            child: Row(children: const [
              Icon(Icons.lock, color: Color(0xFF9B5CFF), size: 11),
              SizedBox(width: 4),
              Text('Unlock',
                  style: TextStyle(
                      color: Color(0xFF9B5CFF), fontSize: 11)),
            ]),
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String value;
  const _MiniStat({required this.icon, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: Colors.white38, size: 11),
      const SizedBox(width: 2),
      Text(value,
          style:
              const TextStyle(color: Colors.white38, fontSize: 10)),
    ]);
  }
}

class _FilterPill extends StatelessWidget {
  final String label;
  final bool isSelected;
  const _FilterPill(
      {required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: isSelected
            ? const Color(0xFF7B2FFF)
            : const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(16),
        border: isSelected
            ? null
            : Border.all(color: const Color(0xFF2A2A40)),
      ),
      child: Center(
        child: Text(label,
            style: TextStyle(
                color:
                    isSelected ? Colors.white : Colors.white60,
                fontSize: 12,
                fontWeight: isSelected
                    ? FontWeight.w600
                    : FontWeight.w400)),
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  final int activeIndex;
  const _BottomNavBar({required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: const BoxDecoration(
        color: Color(0xFF0D0D1E),
        border:
            Border(top: BorderSide(color: Color(0xFF2A2A40))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(
              icon: Icons.home_outlined,
              label: 'Home',
              isActive: activeIndex == 0),
          _NavItem(
              icon: Icons.explore_outlined,
              label: 'Discover',
              isActive: activeIndex == 1),
          Container(
            width: 44,
            height: 44,
            decoration: const BoxDecoration(
                color: Color(0xFF7B2FFF),
                shape: BoxShape.circle),
            child: const Icon(Icons.add,
                color: Colors.white, size: 24),
          ),
          _NavItemBadge(
              icon: Icons.chat_bubble_outline,
              label: 'Chats',
              badge: '3',
              isActive: activeIndex == 3),
          _NavItem(
              icon: Icons.person_outline,
              label: 'Profile',
              isActive: activeIndex == 4),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  const _NavItem(
      {required this.icon,
      required this.label,
      required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon,
            color: isActive
                ? const Color(0xFF9B5CFF)
                : Colors.white38,
            size: 22),
        const SizedBox(height: 2),
        Text(label,
            style: TextStyle(
                color: isActive
                    ? const Color(0xFF9B5CFF)
                    : Colors.white38,
                fontSize: 10)),
      ],
    );
  }
}

class _NavItemBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final String badge;
  final bool isActive;
  const _NavItemBadge(
      {required this.icon,
      required this.label,
      required this.badge,
      required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Stack(children: [
          Icon(icon,
              color: isActive
                  ? const Color(0xFF9B5CFF)
                  : Colors.white38,
              size: 22),
          Positioned(
            top: 0,
            right: 0,
            child: Container(
              width: 14,
              height: 14,
              decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle),
              child: Center(
                  child: Text(badge,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 8,
                          fontWeight: FontWeight.bold))),
            ),
          ),
        ]),
        const SizedBox(height: 2),
        Text(label,
            style: TextStyle(
                color: isActive
                    ? const Color(0xFF9B5CFF)
                    : Colors.white38,
                fontSize: 10)),
      ],
    );
  }
}
