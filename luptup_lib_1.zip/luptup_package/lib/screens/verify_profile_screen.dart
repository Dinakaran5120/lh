import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class VerifyProfileScreen extends StatelessWidget {
  const VerifyProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 16),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(Icons.arrow_back_ios,
                        color: Color(0xFF9B5CFF), size: 20),
                  ),
                  const Expanded(
                    child: Text(
                      'Verify Your Profile',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: const Text(
                      'How it works?',
                      style: TextStyle(
                        color: Color(0xFF9B5CFF),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(height: 1, color: const Color(0xFF2A2A40)),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20, vertical: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Hero badge
                    Center(
                      child: SizedBox(
                        width: 160,
                        height: 160,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: 140,
                              height: 140,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: [
                                    const Color(0xFF7B2FFF)
                                        .withOpacity(0.3),
                                    const Color(0xFF2A1A4A),
                                  ],
                                ),
                              ),
                              child: const Icon(Icons.verified_user,
                                  color: Color(0xFF9B5CFF), size: 60),
                            ),
                            Positioned(
                              top: 10,
                              right: 10,
                              child: Container(
                                width: 32,
                                height: 32,
                                decoration: const BoxDecoration(
                                  color: Color(0xFF7B2FFF),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.verified,
                                    color: Colors.white, size: 16),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Headline
                    RichText(
                      textAlign: TextAlign.center,
                      text: const TextSpan(
                        children: [
                          TextSpan(
                            text: 'Get Your\n',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 26,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          TextSpan(
                            text: 'Verified Badge 🛡️',
                            style: TextStyle(
                              color: Color(0xFF9B5CFF),
                              fontSize: 26,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    const Text(
                      'Be real, build trust and\nget more meaningful matches.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.white60, fontSize: 13),
                    ),

                    const SizedBox(height: 24),

                    // Benefits 2×2 grid
                    GridView.count(
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.9,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      children: const [
                        _BenefitCard(
                          icon: Icons.visibility,
                          title: 'Stand Out',
                          subtitle: 'Get noticed more',
                        ),
                        _BenefitCard(
                          icon: Icons.favorite,
                          title: 'Build Trust',
                          subtitle: 'People feel safer connecting',
                        ),
                        _BenefitCard(
                          icon: Icons.group,
                          title: 'Better Matches',
                          subtitle:
                              'Higher chance of meaningful matches',
                        ),
                        _BenefitCard(
                          icon: Icons.bolt,
                          title: 'Priority Boost',
                          subtitle: 'Your profile gets more visibility',
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Selfie verification title
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Selfie Verification',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Quick, easy and secure',
                        style: TextStyle(
                            color: Colors.white54, fontSize: 12),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Steps row
                    Row(
                      children: [
                        const _VerificationStep(
                          icon: Icons.camera_alt,
                          stepNum: '1',
                          title: 'Take a Selfie',
                          subtitle:
                              'Take a clear selfie in\ngood lighting',
                        ),
                        Expanded(
                          child: Container(
                              height: 1,
                              color: const Color(0xFF2A2A40)),
                        ),
                        const _VerificationStep(
                          icon: Icons.face,
                          stepNum: '2',
                          title: 'Follow the Frame',
                          subtitle:
                              'Position your face\ninside the frame',
                        ),
                        Expanded(
                          child: Container(
                              height: 1,
                              color: const Color(0xFF2A2A40)),
                        ),
                        const _VerificationStep(
                          icon: Icons.verified,
                          stepNum: '3',
                          title: 'Get Verified',
                          subtitle:
                              "We'll verify and add\nthe badge",
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Gift promo card
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1E32),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: const BoxDecoration(
                              color: Color(0xFF2A1A4A),
                              shape: BoxShape.circle,
                            ),
                            child: const Center(
                              child: Text('🎁',
                                  style: TextStyle(fontSize: 22)),
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Text(
                              'Verified members get 3x more profile\nvisits and better match requests!',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                                height: 1.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),

            // CTA + privacy note
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: () => context.pop(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF7B2FFF),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        elevation: 0,
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.camera_alt,
                              color: Colors.white, size: 20),
                          SizedBox(width: 8),
                          Text(
                            'Verify with Selfie',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.lock_outline,
                          color: Colors.white38, size: 13),
                      SizedBox(width: 4),
                      Text(
                        'Your selfie is only used for verification\nand stays private.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.white38, fontSize: 11),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BenefitCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _BenefitCard({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: const Color(0xFF9B5CFF), size: 22),
          const SizedBox(height: 6),
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(subtitle,
              style: const TextStyle(
                  color: Colors.white54, fontSize: 10),
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

class _VerificationStep extends StatelessWidget {
  final IconData icon;
  final String stepNum;
  final String title;
  final String subtitle;

  const _VerificationStep({
    required this.icon,
    required this.stepNum,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E32),
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFF2A2A40)),
          ),
          child: Center(
            child: Icon(icon, color: const Color(0xFF9B5CFF), size: 24),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          title,
          style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w600),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 3),
        Text(
          subtitle,
          textAlign: TextAlign.center,
          style:
              const TextStyle(color: Colors.white54, fontSize: 9.5),
        ),
      ],
    );
  }
}
