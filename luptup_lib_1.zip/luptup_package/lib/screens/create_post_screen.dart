import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class CreatePostScreen extends StatelessWidget {
  const CreatePostScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(Icons.close,
                        color: Color(0xFF1A1A1A), size: 22),
                  ),
                  const Expanded(
                    child: Text(
                      'Create Post',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFF1A1A1A),
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: const Text(
                      'Drafts',
                      style: TextStyle(
                        color: Color(0xFF7B2FFF),
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Container(height: 1, color: const Color(0xFFE0E0E0)),

            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Post type tabs
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          16, 12, 16, 0),
                      child: Row(
                        children: [
                          _PostTypeTab(
                            icon: Icons.text_fields,
                            label: 'Text',
                            isSelected: false,
                          ),
                          const SizedBox(width: 8),
                          _PostTypeTab(
                            icon: Icons.image_outlined,
                            label: 'Photo / Video',
                            isSelected: false,
                          ),
                          const SizedBox(width: 8),
                          _PostTypeTab(
                            icon: Icons.videocam_outlined,
                            label: 'Video',
                            isSelected: false,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Text input
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      child: TextField(
                        minLines: 3,
                        maxLines: 6,
                        style: TextStyle(
                            color: Color(0xFF1A1A1A), fontSize: 15),
                        decoration: InputDecoration(
                          hintText: "What's on your mind?",
                          hintStyle: TextStyle(
                              color: Color(0xFFAAAAAA), fontSize: 15),
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding: EdgeInsets.zero,
                        ),
                      ),
                    ),

                    const SizedBox(height: 8),

                    // Hashtag row
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Row(
                        children: const [
                          Icon(Icons.tag,
                              color: Color(0xFF9B5CFF), size: 16),
                          Text(
                            ' Add Hashtags',
                            style: TextStyle(
                                color: Color(0xFF9B5CFF),
                                fontSize: 13),
                          ),
                          Spacer(),
                          Text(
                            '0/500',
                            style: TextStyle(
                                color: Color(0xFFAAAAAA),
                                fontSize: 11),
                          ),
                        ],
                      ),
                    ),

                    Container(
                        height: 1,
                        color: const Color(0xFFEEEEEE)),

                    // Vibe section header
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          16, 12, 16, 8),
                      child: Row(
                        mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            "What's the vibe?",
                            style: TextStyle(
                              color: Color(0xFF1A1A1A),
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {},
                            child: const Text(
                              'View all',
                              style: TextStyle(
                                  color: Color(0xFF7B2FFF),
                                  fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Vibe chips
                    SizedBox(
                      height: 56,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16),
                        children: const [
                          _VibeChip(
                            emoji: '❤️',
                            label: 'Loved',
                            bgColor: Color(0xFFFFE5E5),
                            isSelected: true,
                          ),
                          SizedBox(width: 10),
                          _VibeChip(
                            emoji: '🎉',
                            label: 'Excited',
                            bgColor: Color(0xFFFFF3E0),
                            isSelected: false,
                          ),
                          SizedBox(width: 10),
                          _VibeChip(
                            emoji: '✈️',
                            label: 'Travel',
                            bgColor: Color(0xFFE5F0FF),
                            isSelected: false,
                          ),
                          SizedBox(width: 10),
                          _VibeChip(
                            emoji: '🎊',
                            label: 'Party Vibe',
                            bgColor: Color(0xFFF5E5FF),
                            isSelected: false,
                          ),
                          SizedBox(width: 10),
                          _VibeChip(
                            emoji: '😌',
                            label: 'Chill',
                            bgColor: Color(0xFFE5F5E5),
                            isSelected: false,
                          ),
                          SizedBox(width: 10),
                          _VibeChip(
                            emoji: '🏔',
                            label: 'Adventure',
                            bgColor: Color(0xFFFFF5E5),
                            isSelected: false,
                          ),
                          SizedBox(width: 10),
                          _VibeChip(
                            emoji: '☀️',
                            label: 'Sunshine',
                            bgColor: Color(0xFFFFFDE5),
                            isSelected: false,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),
                    Container(
                        height: 1,
                        color: const Color(0xFFEEEEEE)),

                    // Who can see
                    const Padding(
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 10),
                      child: Text(
                        'Who can see this post?',
                        style: TextStyle(
                          color: Color(0xFF1A1A1A),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16),
                      child: Column(
                        children: const [
                          _VisibilityOption(
                            icon: Icons.public,
                            title: 'Everyone',
                            subtitle:
                                'Anyone on Lup Tup can see this post',
                            isSelected: true,
                          ),
                          SizedBox(height: 8),
                          _VisibilityOption(
                            icon: Icons.lock_outline,
                            title: 'Followers Only',
                            subtitle:
                                'Only your followers can see this post',
                            isSelected: false,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Support creators toggle
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: const [
                                Row(
                                  children: [
                                    Text(
                                      'Support creators',
                                      style: TextStyle(
                                          color: Color(0xFF1A1A1A),
                                          fontSize: 13),
                                    ),
                                    SizedBox(width: 4),
                                    Icon(Icons.info_outline,
                                        color: Color(0xFFAAAAAA),
                                        size: 14),
                                  ],
                                ),
                                SizedBox(height: 3),
                                Text(
                                  'Creators earn from likes, comments, super\nlikes and coin contributions.',
                                  style: TextStyle(
                                      color: Color(0xFF888888),
                                      fontSize: 11,
                                      height: 1.4),
                                ),
                              ],
                            ),
                          ),
                          Switch(
                            value: true,
                            onChanged: (_) {},
                            activeColor: const Color(0xFF7B2FFF),
                          ),
                        ],
                      ),
                    ),

                    // Allow Coin Contributions
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          16, 8, 16, 0),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Allow Coin Contributions',
                              style: TextStyle(
                                  color: Color(0xFF1A1A1A),
                                  fontSize: 13),
                            ),
                          ),
                          Switch(
                            value: true,
                            onChanged: (_) {},
                            activeColor: const Color(0xFF7B2FFF),
                          ),
                        ],
                      ),
                    ),

                    // Suggested Contribution
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Suggested Contribution',
                              style: TextStyle(
                                  color: Color(0xFF1A1A1A),
                                  fontSize: 13),
                            ),
                          ),
                          Container(
                            height: 28,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF5F5F5),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Row(
                              children: const [
                                Text('🪙',
                                    style: TextStyle(fontSize: 13)),
                                SizedBox(width: 4),
                                Text('10',
                                    style: TextStyle(
                                        color: Color(0xFF1A1A1A),
                                        fontSize: 13,
                                        fontWeight:
                                            FontWeight.w500)),
                                SizedBox(width: 2),
                                Icon(
                                    Icons.keyboard_arrow_down,
                                    color: Color(0xFF888888),
                                    size: 14),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Advanced Options
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          16, 4, 16, 0),
                      child: Container(
                        height: 52,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF7F7F7),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14),
                        child: Row(
                          children: const [
                            Icon(Icons.settings_outlined,
                                color: Color(0xFF555555), size: 18),
                            SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.center,
                                children: [
                                  Text('More options',
                                      style: TextStyle(
                                          color: Color(0xFF1A1A1A),
                                          fontSize: 13,
                                          fontWeight:
                                              FontWeight.w600)),
                                  Text(
                                      'Location, tags, permissions',
                                      style: TextStyle(
                                          color: Color(0xFF888888),
                                          fontSize: 11)),
                                ],
                              ),
                            ),
                            Icon(Icons.chevron_right,
                                color: Color(0xFFAAAAAA), size: 18),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),
                  ],
                ),
              ),
            ),

            // Share Post button
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: () => context.pop(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF7B2FFF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'Share Post',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PostTypeTab extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;

  const _PostTypeTab({
    required this.icon,
    required this.label,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: isSelected
            ? const Color(0xFFEEE5FF)
            : const Color(0xFFF5F5F5),
        borderRadius: BorderRadius.circular(18),
        border: isSelected
            ? Border.all(color: const Color(0xFF7B2FFF), width: 1)
            : null,
      ),
      child: Row(
        children: [
          Icon(icon,
              color: isSelected
                  ? const Color(0xFF7B2FFF)
                  : const Color(0xFF888888),
              size: 16),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: isSelected
                  ? const Color(0xFF7B2FFF)
                  : const Color(0xFF444444),
              fontSize: 12,
              fontWeight: isSelected
                  ? FontWeight.w600
                  : FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }
}

class _VibeChip extends StatelessWidget {
  final String emoji;
  final String label;
  final Color bgColor;
  final bool isSelected;

  const _VibeChip({
    required this.emoji,
    required this.label,
    required this.bgColor,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: bgColor,
            shape: BoxShape.circle,
            border: isSelected
                ? Border.all(
                    color: const Color(0xFF7B2FFF), width: 2)
                : null,
          ),
          child: Center(
            child: Text(emoji,
                style: const TextStyle(fontSize: 18)),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
              color: Color(0xFF444444), fontSize: 10),
        ),
      ],
    );
  }
}

class _VisibilityOption extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool isSelected;

  const _VisibilityOption({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        color: const Color(0xFFF7F7F7),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: const BoxDecoration(
              color: Color(0xFFEEEEEE),
              shape: BoxShape.circle,
            ),
            child: Icon(icon,
                color: const Color(0xFF555555), size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: Color(0xFF1A1A1A),
                        fontSize: 13,
                        fontWeight: FontWeight.w600)),
                Text(subtitle,
                    style: const TextStyle(
                        color: Color(0xFF888888), fontSize: 11)),
              ],
            ),
          ),
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isSelected
                  ? const Color(0xFF7B2FFF)
                  : Colors.transparent,
              border: Border.all(
                color: isSelected
                    ? const Color(0xFF7B2FFF)
                    : const Color(0xFFCCCCCC),
                width: 1.5,
              ),
            ),
            child: isSelected
                ? const Icon(Icons.circle,
                    color: Colors.white, size: 10)
                : null,
          ),
        ],
      ),
    );
  }
}
