import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class EditPreferencesScreen extends StatelessWidget {
  const EditPreferencesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(
                      Icons.arrow_back_ios,
                      color: Color(0xFF9B5CFF),
                      size: 20,
                    ),
                  ),
                  const Expanded(
                    child: Text(
                      'Edit Preferences',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                ],
              ),
            ),
            Container(height: 1, color: const Color(0xFF2A2A40)),

            // Scrollable content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // I'm looking for
                    const Text(
                      "I'm looking for",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        _GenderChip(label: 'Women', isSelected: false),
                        const SizedBox(width: 8),
                        _GenderChip(label: 'Men', isSelected: false),
                        const SizedBox(width: 8),
                        _GenderChip(label: 'Everyone', isSelected: true),
                      ],
                    ),

                    const SizedBox(height: 22),

                    // Age Range
                    const Text(
                      'Age Range',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('21',
                            style: TextStyle(
                                color: Colors.white, fontSize: 13)),
                        Text('30',
                            style: TextStyle(
                                color: Colors.white, fontSize: 13)),
                      ],
                    ),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: const Color(0xFF7B2FFF),
                        inactiveTrackColor: const Color(0xFF2A2A40),
                        thumbColor: const Color(0xFF7B2FFF),
                        overlayColor:
                            const Color(0xFF7B2FFF).withOpacity(0.2),
                        trackHeight: 3,
                        thumbShape: const RoundSliderThumbShape(
                            enabledThumbRadius: 10),
                      ),
                      child: RangeSlider(
                        values: const RangeValues(21, 30),
                        min: 18,
                        max: 50,
                        activeColor: const Color(0xFF7B2FFF),
                        inactiveColor: const Color(0xFF2A2A40),
                        onChanged: (_) {},
                      ),
                    ),

                    const SizedBox(height: 22),

                    // Location
                    Row(
                      children: [
                        const Text(
                          'Location',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () {},
                          child: const Icon(
                            Icons.edit_outlined,
                            color: Color(0xFF9B5CFF),
                            size: 18,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Delhi, India',
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: 13,
                      ),
                    ),

                    const SizedBox(height: 22),

                    // Interests
                    const Text(
                      'Interests',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        const _TagChip(label: 'Photography'),
                        const _TagChip(label: 'Coffee'),
                        const _TagChip(label: 'Travel'),
                        const _TagChip(label: 'Music'),
                        const _TagChip(label: 'Books'),
                        const _TagChip(label: 'Animals'),
                        GestureDetector(
                          onTap: () {},
                          child: Container(
                            height: 32,
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: const Color(0xFF9B5CFF),
                                width: 1,
                              ),
                            ),
                            child: const Center(
                              child: Text(
                                '+ Add more',
                                style: TextStyle(
                                  color: Color(0xFF9B5CFF),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 22),

                    // Distance
                    const Text(
                      'Distance',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('10 km',
                            style: TextStyle(
                                color: Colors.white54, fontSize: 12)),
                        Text('100 km',
                            style: TextStyle(
                                color: Colors.white54, fontSize: 12)),
                      ],
                    ),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: const Color(0xFF7B2FFF),
                        inactiveTrackColor: const Color(0xFF2A2A40),
                        thumbColor: const Color(0xFF7B2FFF),
                        overlayColor:
                            const Color(0xFF7B2FFF).withOpacity(0.2),
                        trackHeight: 3,
                        thumbShape: const RoundSliderThumbShape(
                            enabledThumbRadius: 10),
                      ),
                      child: Slider(
                        value: 100,
                        min: 1,
                        max: 100,
                        activeColor: const Color(0xFF7B2FFF),
                        inactiveColor: const Color(0xFF2A2A40),
                        onChanged: (_) {},
                      ),
                    ),

                    const SizedBox(height: 12),
                  ],
                ),
              ),
            ),

            // Save button
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
              child: SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: () => context.pop(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF7B2FFF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'Save Preferences',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GenderChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  const _GenderChip({required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFF7B2FFF) : const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(18),
        border: isSelected
            ? null
            : Border.all(color: const Color(0xFF2A2A40)),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white60,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _TagChip extends StatelessWidget {
  final String label;
  const _TagChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E32),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF9B5CFF), width: 1),
      ),
      child: Center(
        child: Text(
          label,
          style: const TextStyle(
            color: Color(0xFF9B5CFF),
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
