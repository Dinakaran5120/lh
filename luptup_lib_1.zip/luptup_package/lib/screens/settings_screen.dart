import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: const Text(
                'Settings',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Container(height: 1, color: const Color(0xFF2A2A40)),

            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Profile card
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      child: Row(
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              color: const Color(0xFF2A2A40),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.favorite,
                                color: Color(0xFF9B5CFF), size: 26),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: const [
                                  Text(
                                    'Lup Tup',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Icon(Icons.verified,
                                      color: Color(0xFF9B5CFF), size: 16),
                                ],
                              ),
                              const SizedBox(height: 2),
                              const Text(
                                'Meaningful connections start here',
                                style: TextStyle(
                                    color: Colors.white54, fontSize: 12),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    Container(height: 1, color: const Color(0xFF2A2A40)),

                    // Account section
                    _SectionHeader(title: 'Account'),
                    _SettingsRow(
                        icon: Icons.person_outline, label: 'Edit Profile'),
                    _SettingsRow(icon: Icons.tune, label: 'Preferences'),
                    _SettingsRow(
                        icon: Icons.lock_outline, label: 'Privacy'),
                    _SettingsRow(
                        icon: Icons.notifications_outlined,
                        label: 'Notifications'),
                    _SettingsRow(
                        icon: Icons.security, label: 'Safety & Security'),

                    Container(height: 1, color: const Color(0xFF2A2A40)),

                    // Support section
                    _SectionHeader(title: 'Support'),
                    _SettingsRow(
                        icon: Icons.help_outline, label: 'Help Center'),
                    _SettingsRow(
                        icon: Icons.phone_outlined, label: 'Contact Us'),
                    _SettingsRow(
                        icon: Icons.flag_outlined,
                        label: 'Report a Problem'),

                    Container(height: 1, color: const Color(0xFF2A2A40)),

                    // More section
                    _SectionHeader(title: 'More'),
                    _SettingsRow(
                        icon: Icons.person_add_outlined,
                        label: 'Invite Friends'),
                    _SettingsRow(
                        icon: Icons.star_outline, label: 'Rate Lup Tup'),
                    _SettingsRow(
                        icon: Icons.info_outline, label: 'About Lup Tup'),

                    Container(height: 1, color: const Color(0xFF2A2A40)),

                    // Log Out
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: _SettingsRow(
                        icon: Icons.logout,
                        label: 'Log Out',
                        isDestructive: true,
                      ),
                    ),

                    // Version
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Center(
                        child: Text(
                          'Version 1.0.3',
                          style: TextStyle(
                              color: Colors.white38, fontSize: 12),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _BottomNavBar(activeIndex: 4),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          color: Colors.white38,
          fontSize: 12,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.8,
        ),
      ),
    );
  }
}

class _SettingsRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isDestructive;
  final VoidCallback? onTap;

  const _SettingsRow({
    required this.icon,
    required this.label,
    this.isDestructive = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color =
        isDestructive ? Colors.redAccent : Colors.white60;
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
      height: 52,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  color: isDestructive ? Colors.redAccent : Colors.white,
                  fontSize: 14,
                ),
              ),
            ),
            if (!isDestructive)
              const Icon(Icons.chevron_right,
                  color: Colors.white30, size: 18),
          ],
        ),
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  final int activeIndex;
  const _BottomNavBar({required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: const BoxDecoration(
        color: Color(0xFF0D0D1E),
        border:
            Border(top: BorderSide(color: Color(0xFF2A2A40), width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(
              icon: Icons.explore_outlined,
              label: 'Discover',
              isActive: activeIndex == 0),
          _NavItem(
              icon: Icons.mood,
              label: 'Mood',
              isActive: activeIndex == 1),
          _NavItem(
              icon: Icons.favorite_border,
              label: 'Matches',
              isActive: activeIndex == 2),
          _NavItem(
              icon: Icons.chat_bubble_outline,
              label: 'Chats',
              isActive: activeIndex == 3),
          _NavItem(
              icon: Icons.person_outline,
              label: 'Profile',
              isActive: activeIndex == 4),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  const _NavItem(
      {required this.icon,
      required this.label,
      required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon,
            color:
                isActive ? const Color(0xFF9B5CFF) : Colors.white38,
            size: 22),
        const SizedBox(height: 2),
        Text(label,
            style: TextStyle(
                color: isActive
                    ? const Color(0xFF9B5CFF)
                    : Colors.white38,
                fontSize: 10)),
      ],
    );
  }
}
