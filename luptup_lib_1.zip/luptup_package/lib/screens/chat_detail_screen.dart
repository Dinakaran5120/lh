import 'dart:math';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../navigation/app_routes.dart';

class ChatDetailScreen extends StatelessWidget {
  const ChatDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: Column(
        children: [
          // Header
          Container(
            decoration: const BoxDecoration(
              color: Color(0xFF0D0D1E),
              border: Border(
                bottom: BorderSide(color: Color(0xFF2A2A40), width: 1),
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => context.pop(),
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.white,
                        size: 18,
                      ),
                    ),
                    Stack(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xFF2A2A40),
                          ),
                          child: const ClipOval(
                            child: Icon(Icons.person,
                                color: Colors.white38, size: 22),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: const Color(0xFF2ECC71),
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: const Color(0xFF0D0D1E), width: 2),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Anaya',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 1),
                          Row(
                            children: [
                              Icon(Icons.circle,
                                  color: Color(0xFF2ECC71), size: 7),
                              SizedBox(width: 4),
                              Text(
                                'Online',
                                style: TextStyle(
                                  color: Color(0xFF2ECC71),
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.call_outlined,
                          color: Color(0xFF9B5CFF), size: 20),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.videocam_outlined,
                          color: Color(0xFF9B5CFF), size: 20),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.more_vert,
                          color: Colors.white54, size: 20),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Disappearing media notice
          Container(
            color: const Color(0xFF1A1A2E),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                const Icon(Icons.timer_outlined,
                    color: Colors.white54, size: 16),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'Photos and videos disappear after being seen once.',
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 11,
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {},
                  child: const Text(
                    'Learn more',
                    style: TextStyle(
                      color: Color(0xFF9B5CFF),
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Messages
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              children: [
                // Date separator
                const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      'Today',
                      style: TextStyle(color: Colors.white38, fontSize: 11),
                    ),
                  ),
                ),

                // Message 1 — received
                _ReceivedBubble(
                  text: 'That sunset photo is stunning 😍\nWhere was that?',
                  time: '9:40 AM',
                  isRead: true,
                ),
                const SizedBox(height: 8),

                // Message 2 — sent
                _SentBubble(
                  text: 'Thanks! It was in Bali 🌴\nYou should visit sometime.',
                  time: '9:41 AM',
                ),
                const SizedBox(height: 8),

                // Message 3 — sent
                _SentBubble(
                  text: 'Adding it to my list!\nYou free this weekend?',
                  time: '9:41 AM',
                  isRead: true,
                ),
                const SizedBox(height: 8),

                // Message 4 — photo bubble sent
                _PhotoBubble(time: '9:42 AM'),
                const SizedBox(height: 8),

                // Message 5 — audio received
                _AudioBubble(
                  isSent: false,
                  duration: '0:12',
                  time: '9:43 AM',
                ),
                const SizedBox(height: 8),

                // Message 6 — audio sent
                _AudioBubble(
                  isSent: true,
                  duration: '0:09',
                  time: '9:44 AM',
                  isRead: true,
                ),
                const SizedBox(height: 8),

                // Message 7 — received
                _ReceivedBubble(
                  text: 'Yes! Let\'s catch up over coffee ☕',
                  time: '9:43 AM',
                ),
                const SizedBox(height: 8),

                // Message 8 — sent
                _SentBubble(
                  text: 'Perfect! See you there 💜',
                  time: '9:44 AM',
                  isRead: true,
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),

          // Input bar
          Container(
            decoration: const BoxDecoration(
              color: Color(0xFF0D0D1E),
              border: Border(
                top: BorderSide(color: Color(0xFF2A2A40), width: 1),
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: const BoxDecoration(
                    color: Color(0xFF1E1E32),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.add,
                      color: Colors.white54, size: 20),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1E32),
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: Row(
                      children: [
                        const SizedBox(width: 14),
                        const Expanded(
                          child: Text(
                            'Type a message...',
                            style: TextStyle(
                              color: Colors.white38,
                              fontSize: 13,
                            ),
                          ),
                        ),
                        const Icon(Icons.emoji_emotions_outlined,
                            color: Colors.white38, size: 20),
                        const SizedBox(width: 10),
                        const Icon(Icons.card_giftcard,
                            color: Colors.white38, size: 20),
                        const SizedBox(width: 12),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Bottom safe area padding
          SizedBox(height: MediaQuery.of(context).padding.bottom),
        ],
      ),
    );
  }
}

// ── Received bubble ──────────────────────────────────────────────────────────
class _ReceivedBubble extends StatelessWidget {
  final String text;
  final String time;
  final bool isRead;

  const _ReceivedBubble({
    required this.text,
    required this.time,
    this.isRead = false,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            constraints: const BoxConstraints(maxWidth: 260),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(
              color: Color(0xFF1E1E32),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(16),
                bottomLeft: Radius.circular(16),
                bottomRight: Radius.circular(16),
              ),
            ),
            child: Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                height: 1.4,
              ),
            ),
          ),
          const SizedBox(height: 3),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                time,
                style: const TextStyle(
                  color: Colors.white38,
                  fontSize: 10,
                ),
              ),
              if (isRead) ...[
                const SizedBox(width: 4),
                const Icon(Icons.done_all, color: Colors.white38, size: 12),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

// ── Sent bubble ───────────────────────────────────────────────────────────────
class _SentBubble extends StatelessWidget {
  final String text;
  final String time;
  final bool isRead;

  const _SentBubble({
    required this.text,
    required this.time,
    this.isRead = false,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            constraints: const BoxConstraints(maxWidth: 260),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(
              color: Color(0xFF7B2FFF),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(4),
                bottomLeft: Radius.circular(16),
                bottomRight: Radius.circular(16),
              ),
            ),
            child: Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                height: 1.4,
              ),
            ),
          ),
          const SizedBox(height: 3),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                time,
                style: const TextStyle(
                  color: Colors.white38,
                  fontSize: 10,
                ),
              ),
              if (isRead) ...[
                const SizedBox(width: 4),
                const Icon(Icons.done_all,
                    color: Color(0xFF9B5CFF), size: 12),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

// ── Photo bubble ──────────────────────────────────────────────────────────────
class _PhotoBubble extends StatelessWidget {
  final String time;
  const _PhotoBubble({required this.time});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            width: 170,
            height: 110,
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A2E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF2A1040), Color(0xFF1A2040)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                Positioned(
                  top: 8,
                  left: 10,
                  child: Row(
                    children: [
                      const Icon(Icons.visibility_off,
                          color: Colors.white60, size: 13),
                      const SizedBox(width: 4),
                      const Text(
                        'Seen once',
                        style:
                            TextStyle(color: Colors.white60, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 3),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.visibility,
                  color: Colors.white38, size: 10),
              const SizedBox(width: 3),
              Text(
                time,
                style: const TextStyle(
                  color: Colors.white38,
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Audio bubble ──────────────────────────────────────────────────────────────
class _AudioBubble extends StatelessWidget {
  final bool isSent;
  final String duration;
  final String time;
  final bool isRead;

  const _AudioBubble({
    required this.isSent,
    required this.duration,
    required this.time,
    this.isRead = false,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isSent ? Alignment.centerRight : Alignment.centerLeft,
      child: Column(
        crossAxisAlignment:
            isSent ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Container(
            width: 200,
            height: 48,
            decoration: BoxDecoration(
              color: isSent
                  ? const Color(0xFF7B2FFF)
                  : const Color(0xFF1E1E32),
              borderRadius: BorderRadius.circular(24),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children: [
                Icon(
                  Icons.play_circle_filled,
                  color: isSent ? Colors.white : const Color(0xFF9B5CFF),
                  size: 30,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: CustomPaint(
                    painter: _WaveformPainter(
                      color: isSent
                          ? Colors.white.withOpacity(0.7)
                          : const Color(0xFF9B5CFF),
                    ),
                    size: const Size(double.infinity, 24),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  duration,
                  style: TextStyle(
                    color: isSent ? Colors.white70 : Colors.white54,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 3),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                time,
                style: const TextStyle(color: Colors.white38, fontSize: 10),
              ),
              if (isRead && isSent) ...[
                const SizedBox(width: 4),
                const Icon(Icons.done_all,
                    color: Color(0xFF9B5CFF), size: 12),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

// ── Waveform painter ──────────────────────────────────────────────────────────
class _WaveformPainter extends CustomPainter {
  final Color color;
  _WaveformPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    final random = Random(42);
    final barCount = 28;
    final barWidth = 2.0;
    final gap = (size.width - barCount * barWidth) / (barCount - 1);

    for (int i = 0; i < barCount; i++) {
      final barHeight = (random.nextDouble() * 0.7 + 0.15) * size.height;
      final x = i * (barWidth + gap) + barWidth / 2;
      final top = (size.height - barHeight) / 2;
      canvas.drawLine(
        Offset(x, top),
        Offset(x, top + barHeight),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
