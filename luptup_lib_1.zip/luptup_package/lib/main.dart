// ============================================================
// main.dart
// Lup Tup — App Entry Point
// Navigation + Theme wiring only. No UI widget code.
// ============================================================

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart'; // add provider: ^6.x to pubspec.yaml

import 'navigation/app_router.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Transparent status bar
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  runApp(
    // Provide ThemeNotifier at the root so any screen can access it
    ChangeNotifierProvider(
      create: (_) => ThemeNotifier(),
      child: const LupTupApp(),
    ),
  );
}

class LupTupApp extends StatelessWidget {
  const LupTupApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeNotifier = context.watch<ThemeNotifier>();

    return MaterialApp.router(
      title: 'Lup Tup',
      debugShowCheckedModeBanner: false,

      // ── Theme ──────────────────────────────────────────────
      theme: lupTupLightTheme,
      darkTheme: lupTupDarkTheme,
      themeMode: themeNotifier.themeMode, // controlled by ThemeNotifier

      // ── Router ─────────────────────────────────────────────
      routerConfig: appRouter,
    );
  }
}
