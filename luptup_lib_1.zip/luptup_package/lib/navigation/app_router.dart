// ============================================================
// app_router.dart
// Lup Tup — GoRouter Configuration
// ============================================================

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../screens/splash_login_screen.dart';
import '../screens/phone_verification_screen.dart';
import '../screens/onboarding_slide_screen.dart';
import '../screens/terms_and_conditions_screen.dart';
import '../screens/what_are_you_looking_for_screen.dart';
import '../screens/onboarding_get_started_screen.dart';
import '../screens/create_profile_screen.dart';

import '../screens/discover_screen.dart';
import '../screens/user_profile_detail_screen.dart';

import '../screens/mood_feed_for_you_screen.dart';
import '../screens/mood_feed_following_screen.dart';
import '../screens/mood_feed_trending_screen.dart';

import '../screens/create_post_screen.dart';

import '../screens/groups_home_screen.dart';
import '../screens/all_groups_screen.dart';
import '../screens/group_detail_screen.dart';
import '../screens/create_group_screen.dart';
import '../screens/my_groups_screen.dart';

import '../screens/edit_preferences_screen.dart';
import '../screens/advanced_filters_screen.dart';
import '../screens/matches_screen.dart';
import '../screens/chat_detail_screen.dart';

import '../screens/settings_screen.dart';
import '../screens/introvert_mode_screen.dart';
import '../screens/verify_profile_screen.dart';
import '../screens/lup_tup_premium_screen.dart';

import 'app_routes.dart';
import 'main_shell_screen.dart';

// ── Auth State Notifier (replace with your real auth provider) ──
final _authNotifier = ValueNotifier<bool>(false);

// ── Router ────────────────────────────────────────────────────────────────────
final GoRouter appRouter = GoRouter(
  initialLocation: AppRoutes.splash,
  refreshListenable: _authNotifier,
  redirect: (BuildContext context, GoRouterState state) {
    final isLoggedIn  = _authNotifier.value;
    final isAuthRoute = state.matchedLocation.startsWith('/auth') ||
                        state.matchedLocation == AppRoutes.splash;

    // Redirect logged-in users away from auth screens
    if (isLoggedIn && isAuthRoute) return AppRoutes.discover;

    // Redirect logged-out users away from protected screens
    if (!isLoggedIn && !isAuthRoute) return AppRoutes.splash;

    return null; // no redirect
  },
  routes: [

    // ── Splash / Login ──────────────────────────────────────
    GoRoute(
      path: AppRoutes.splash,
      name: 'splash',
      builder: (context, state) => const SplashLoginScreen(),
    ),

    // ── Auth Flow ───────────────────────────────────────────
    GoRoute(
      path: AppRoutes.phoneVerification,
      name: 'phoneVerification',
      builder: (context, state) => const PhoneVerificationScreen(),
    ),
    GoRoute(
      path: AppRoutes.onboardingSlide,
      name: 'onboardingSlide',
      builder: (context, state) => const OnboardingSlideScreen(),
    ),
    GoRoute(
      path: AppRoutes.termsAndConditions,
      name: 'termsAndConditions',
      builder: (context, state) => const TermsAndConditionsScreen(),
    ),
    GoRoute(
      path: AppRoutes.whatAreYouLookingFor,
      name: 'whatAreYouLookingFor',
      builder: (context, state) => const WhatAreYouLookingForScreen(),
    ),
    GoRoute(
      path: AppRoutes.onboardingGetStarted,
      name: 'onboardingGetStarted',
      builder: (context, state) => const OnboardingGetStartedScreen(),
    ),
    GoRoute(
      path: AppRoutes.createProfile,
      name: 'createProfile',
      builder: (context, state) => const CreateProfileScreen(),
    ),

    // ── Main Shell (hosts BottomNavigationBar) ──────────────
    ShellRoute(
      builder: (context, state, child) => MainShellScreen(child: child),
      routes: [

        // Tab 0 — Home / Discover
        GoRoute(
          path: AppRoutes.discover,
          name: 'discover',
          builder: (context, state) => const DiscoverScreen(),
          routes: [
            GoRoute(
              path: 'profile-detail',
              name: 'userProfileDetail',
              builder: (context, state) => const UserProfileDetailScreen(),
            ),
          ],
        ),

        // Tab 1 — Mood Feed (3 sibling tab screens, same shell level)
        GoRoute(
          path: AppRoutes.moodFeedForYou,
          name: 'moodFeedForYou',
          builder: (context, state) => const MoodFeedForYouScreen(),
        ),
        GoRoute(
          path: AppRoutes.moodFeedFollowing,
          name: 'moodFeedFollowing',
          builder: (context, state) => const MoodFeedFollowingScreen(),
        ),
        GoRoute(
          path: AppRoutes.moodFeedTrending,
          name: 'moodFeedTrending',
          builder: (context, state) => const MoodFeedTrendingScreen(),
        ),

        // Tab 3 — Groups
        GoRoute(
          path: AppRoutes.groupsHome,
          name: 'groupsHome',
          builder: (context, state) => const GroupsHomeScreen(),
          routes: [
            GoRoute(
              path: 'all',
              name: 'allGroups',
              builder: (context, state) => const AllGroupsScreen(),
            ),
            GoRoute(
              path: 'detail',
              name: 'groupDetail',
              builder: (context, state) => const GroupDetailScreen(),
            ),
            GoRoute(
              path: 'create',
              name: 'createGroup',
              builder: (context, state) => const CreateGroupScreen(),
            ),
            GoRoute(
              path: 'my-groups',
              name: 'myGroups',
              builder: (context, state) => const MyGroupsScreen(),
            ),
          ],
        ),

        // Tab 4 — Profile
        GoRoute(
          path: AppRoutes.profile,
          name: 'profile',
          builder: (context, state) => const UserProfileDetailScreen(),
          routes: [
            GoRoute(
              path: 'edit-preferences',
              name: 'editPreferences',
              builder: (context, state) => const EditPreferencesScreen(),
            ),
            GoRoute(
              path: 'advanced-filters',
              name: 'advancedFilters',
              builder: (context, state) => const AdvancedFiltersScreen(),
            ),
            GoRoute(
              path: 'matches',
              name: 'matches',
              builder: (context, state) => const MatchesScreen(),
            ),
            GoRoute(
              path: 'chat-detail',
              name: 'chatDetail',
              builder: (context, state) => const ChatDetailScreen(),
            ),
          ],
        ),
      ],
    ),

    // ── Create Post (modal — no bottom nav) ──────────────────
    GoRoute(
      path: AppRoutes.createPost,
      name: 'createPost',
      pageBuilder: (context, state) => const MaterialPage(
        fullscreenDialog: true,
        child: CreatePostScreen(),
      ),
    ),

    // ── Settings & Misc (outside shell — no bottom nav) ─────
    GoRoute(
      path: AppRoutes.settings,
      name: 'settings',
      builder: (context, state) => const SettingsScreen(),
      routes: [
        GoRoute(
          path: 'introvert-mode',
          name: 'introvertMode',
          builder: (context, state) => const IntrovertModeScreen(),
        ),
        GoRoute(
          path: 'verify-profile',
          name: 'verifyProfile',
          builder: (context, state) => const VerifyProfileScreen(),
        ),
        GoRoute(
          path: 'premium',
          name: 'lupTupPremium',
          builder: (context, state) => const LupTupPremiumScreen(),
        ),
      ],
    ),
  ],

  // ── Error screen ────────────────────────────────────────────
  errorBuilder: (context, state) => Scaffold(
    body: Center(
      child: Text('Route not found: ${state.uri}',
          style: const TextStyle(color: Colors.white)),
    ),
  ),
);
