// ============================================================
// app_routes.dart
// Lup Tup — Complete Named Route Registry
// ============================================================

class AppRoutes {
  AppRoutes._();

  // ── Auth ──────────────────────────────────────────────────
  static const String splash              = '/';
  static const String phoneVerification   = '/auth/phone-verification';
  static const String onboardingSlide     = '/auth/onboarding-slide';
  static const String termsAndConditions  = '/auth/terms-and-conditions';
  static const String whatAreYouLookingFor = '/auth/what-are-you-looking-for';
  static const String onboardingGetStarted = '/auth/onboarding-get-started';
  static const String createProfile       = '/auth/create-profile';
  // ── Home / Discover (Tab 0) ───────────────────────────────
  static const String discover           = '/discover';
  static const String userProfileDetail  = '/discover/profile-detail';

  // ── Mood Feed (Tab 1) ─────────────────────────────────────
  static const String moodFeedForYou     = '/mood/for-you';
  static const String moodFeedFollowing  = '/mood/following';
  static const String moodFeedTrending   = '/mood/trending';

  // ── Create Post (Tab 2 — modal) ───────────────────────────
  static const String createPost         = '/create-post';

  // ── Groups (Tab 3) ────────────────────────────────────────
  static const String groupsHome         = '/groups';
  static const String allGroups          = '/groups/all';
  static const String groupDetail        = '/groups/detail';
  static const String createGroup        = '/groups/create';
  static const String myGroups           = '/groups/my-groups';

  // ── Profile (Tab 4) ───────────────────────────────────────
  static const String profile            = '/profile';
  static const String editPreferences    = '/profile/edit-preferences';
  static const String advancedFilters    = '/profile/advanced-filters';
  static const String matches            = '/profile/matches';
  static const String chatDetail         = '/profile/chat-detail';

  // ── Settings & Misc ───────────────────────────────────────
  static const String settings           = '/settings';
  static const String introvertMode      = '/settings/introvert-mode';
  static const String verifyProfile      = '/settings/verify-profile';
  static const String lupTupPremium      = '/settings/premium';
}
