// ============================================================
// main_shell_screen.dart
// Lup Tup — Bottom Navigation Shell
// Hosts all 5 tabs. Each tab keeps its own Navigator state
// via ShellRoute + IndexedStack pattern.
// ============================================================

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'app_routes.dart';

class MainShellScreen extends StatefulWidget {
  final Widget child;
  const MainShellScreen({super.key, required this.child});

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  int _currentIndex = 0;

  // Root route for each tab
  static const List<String> _tabRoots = [
    AppRoutes.discover,       // Tab 0 — Home / Discover
    AppRoutes.moodFeedForYou, // Tab 1 — Mood
    AppRoutes.createPost,     // Tab 2 — Create Post (modal)
    AppRoutes.groupsHome,     // Tab 3 — Groups
    AppRoutes.profile,        // Tab 4 — Profile
  ];

  void _onTabTapped(int index) {
    // Tab 2 (Create Post) is always a modal — never navigates
    if (index == 2) {
      context.push(AppRoutes.createPost);
      return;
    }

    if (index == _currentIndex) {
      // Tap same tab → pop to root of that tab
      context.go(_tabRoots[index]);
    } else {
      setState(() => _currentIndex = index);
      context.go(_tabRoots[index]);
    }
  }

  // Sync tab index from current router location
  int _locationToIndex(String location) {
    if (location.startsWith('/discover'))     return 0;
    if (location.startsWith('/mood'))         return 1;
    if (location.startsWith('/create-post'))  return 2;
    if (location.startsWith('/groups'))       return 3;
    if (location.startsWith('/profile'))      return 4;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).matchedLocation;
    final activeIndex = _locationToIndex(location);

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1E),
      body: widget.child,
      bottomNavigationBar: _LupTupBottomNav(
        activeIndex: activeIndex,
        onTap: _onTabTapped,
      ),
    );
  }
}

// ── Bottom Navigation Bar ─────────────────────────────────────────────────────
class _LupTupBottomNav extends StatelessWidget {
  final int activeIndex;
  final ValueChanged<int> onTap;

  const _LupTupBottomNav({
    required this.activeIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64 + MediaQuery.of(context).padding.bottom,
      decoration: const BoxDecoration(
        color: Color(0xFF0D0D1E),
        border: Border(top: BorderSide(color: Color(0xFF2A2A40), width: 1)),
      ),
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).padding.bottom),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _NavItem(
              icon: Icons.explore_outlined,
              activeIcon: Icons.explore,
              label: 'Discover',
              isActive: activeIndex == 0,
              onTap: () => onTap(0),
            ),
            _NavItem(
              icon: Icons.mood_outlined,
              activeIcon: Icons.mood,
              label: 'Mood',
              isActive: activeIndex == 1,
              onTap: () => onTap(1),
            ),
            // Centre FAB — Create Post
            GestureDetector(
              onTap: () => onTap(2),
              child: Container(
                width: 48,
                height: 48,
                decoration: const BoxDecoration(
                  color: Color(0xFF7B2FFF),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x557B2FFF),
                      blurRadius: 12,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(Icons.add, color: Colors.white, size: 26),
              ),
            ),
            _NavItem(
              icon: Icons.group_outlined,
              activeIcon: Icons.group,
              label: 'Groups',
              isActive: activeIndex == 3,
              onTap: () => onTap(3),
            ),
            _NavItem(
              icon: Icons.person_outline,
              activeIcon: Icons.person,
              label: 'Profile',
              isActive: activeIndex == 4,
              onTap: () => onTap(4),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 60,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isActive ? activeIcon : icon,
              color: isActive ? const Color(0xFF9B5CFF) : Colors.white38,
              size: 22,
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                color: isActive ? const Color(0xFF9B5CFF) : Colors.white38,
                fontSize: 10,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
