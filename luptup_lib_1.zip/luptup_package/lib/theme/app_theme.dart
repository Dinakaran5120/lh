// ============================================================
// app_theme.dart
// Lup Tup — Theme Definitions + ThemeNotifier
// Supports dark mode (default) and light mode (CreatePostScreen)
// Theme toggle persists via shared_preferences.
// ============================================================

import 'package:flutter/material.dart';

// ── Color Tokens ─────────────────────────────────────────────
class LupTupColors {
  LupTupColors._();

  // Shared
  static const Color primaryPurple  = Color(0xFF7B2FFF);
  static const Color accentPurple   = Color(0xFF9B5CFF);
  static const Color coinGold       = Color(0xFFF5A623);
  static const Color onlineGreen    = Color(0xFF2ECC71);

  // Dark palette
  static const Color darkBg         = Color(0xFF0D0D1E);
  static const Color darkCard       = Color(0xFF1E1E32);
  static const Color darkCard2      = Color(0xFF1A1A2E);
  static const Color darkBorder     = Color(0xFF2A2A40);
  static const Color darkSelected   = Color(0xFF2A1A4A);

  // Light palette
  static const Color lightBg        = Color(0xFFFFFFFF);
  static const Color lightCard      = Color(0xFFF7F7F7);
  static const Color lightBorder    = Color(0xFFE0E0E0);
  static const Color lightText      = Color(0xFF1A1A1A);
  static const Color lightTextSub   = Color(0xFF888888);
}

// ── Dark Theme ────────────────────────────────────────────────
final ThemeData lupTupDarkTheme = ThemeData(
  brightness: Brightness.dark,
  useMaterial3: true,
  scaffoldBackgroundColor: LupTupColors.darkBg,
  colorScheme: const ColorScheme.dark(
    primary: LupTupColors.primaryPurple,
    secondary: LupTupColors.accentPurple,
    surface: LupTupColors.darkCard,
    background: LupTupColors.darkBg,
    onPrimary: Colors.white,
    onSecondary: Colors.white,
    onSurface: Colors.white,
    onBackground: Colors.white,
  ),
  fontFamily: 'SF Pro Display', // fallback: system default
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: LupTupColors.primaryPurple,
      foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      elevation: 0,
    ),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: LupTupColors.accentPurple,
      side: const BorderSide(color: LupTupColors.accentPurple),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
    ),
  ),
  switchTheme: SwitchThemeData(
    thumbColor: MaterialStateProperty.all(Colors.white),
    trackColor: MaterialStateProperty.resolveWith((states) =>
      states.contains(MaterialState.selected)
          ? LupTupColors.primaryPurple
          : LupTupColors.darkBorder),
  ),
  dividerTheme: const DividerThemeData(
    color: LupTupColors.darkBorder,
    thickness: 1,
    space: 1,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: LupTupColors.darkBg,
    foregroundColor: Colors.white,
    elevation: 0,
  ),
  sliderTheme: const SliderThemeData(
    activeTrackColor: LupTupColors.primaryPurple,
    inactiveTrackColor: LupTupColors.darkBorder,
    thumbColor: LupTupColors.primaryPurple,
    trackHeight: 3,
  ),
);

// ── Light Theme ───────────────────────────────────────────────
final ThemeData lupTupLightTheme = ThemeData(
  brightness: Brightness.light,
  useMaterial3: true,
  scaffoldBackgroundColor: LupTupColors.lightBg,
  colorScheme: const ColorScheme.light(
    primary: LupTupColors.primaryPurple,
    secondary: LupTupColors.accentPurple,
    surface: LupTupColors.lightCard,
    background: LupTupColors.lightBg,
    onPrimary: Colors.white,
    onSecondary: Colors.white,
    onSurface: LupTupColors.lightText,
    onBackground: LupTupColors.lightText,
  ),
  fontFamily: 'SF Pro Display',
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: LupTupColors.primaryPurple,
      foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      elevation: 0,
    ),
  ),
  switchTheme: SwitchThemeData(
    thumbColor: MaterialStateProperty.all(Colors.white),
    trackColor: MaterialStateProperty.resolveWith((states) =>
      states.contains(MaterialState.selected)
          ? LupTupColors.primaryPurple
          : LupTupColors.lightBorder),
  ),
  dividerTheme: const DividerThemeData(
    color: LupTupColors.lightBorder,
    thickness: 1,
    space: 1,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: LupTupColors.lightBg,
    foregroundColor: LupTupColors.lightText,
    elevation: 0,
  ),
);

// ── Theme Notifier (ChangeNotifier) ───────────────────────────
// Place this in your state management layer (Provider / Riverpod).
// Screens that toggle theme: SettingsScreen → any switch in settings.
class ThemeNotifier extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.dark; // default: dark

  ThemeMode get themeMode => _themeMode;

  bool get isDark => _themeMode == ThemeMode.dark;

  void setDark()  { _themeMode = ThemeMode.dark;   notifyListeners(); }
  void setLight() { _themeMode = ThemeMode.light;  notifyListeners(); }

  void toggle() {
    _themeMode =
        _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
    // TODO: persist via shared_preferences
    // prefs.setBool('isDark', isDark);
  }
}
